# Orquestación de generación SOAP por fases

- Tipo de servicio: SOAP
- Servicio: WsClientes0024
- URL: https://tnd-msa-sp-wsclientes0024-enp.apps.ocpdev.uiotest.bpichinchatest.test/IntegrationBus/soap/WSClientes0024
- Fecha: 2026-06-11T15:20:55.673Z

## Resultado por fase
| Fase | Estado | Detalle |
| --- | --- | --- |
| F1-Generación base | COMPLETADA | Generación SOAP completa para WsClientes0024 (ConsultarIdentificacion01): domain DTOs, port output, adapter, builder, mapper, DTOs técnicos JAXB request/response, XmlConverterException, XmlConverter, SoapWebClientExecutor, application.yml y Helm. |
| F2-Normalización DTO | COMPLETADA | Normalización DTOs WsClientes0024: crear DTOs técnicos faltantes en infrastructure request/response, corregir domain DTO response con campo CIF del XML, actualizar adapter para usar SoapWebClientExecutor+builder+mapper según patrón SOAP. |
| F3-Split y reutilización DTO | COMPLETADA | Refactorización estructural de DTOs SOAP para WsClientes0024: split 1 DTO por archivo, creación de DTOs técnicos request/response en rutas obligatorias, actualización de adapter para usar SoapWebClientExecutor, y actualización de builder/mapper. |
| F4-Garantía DTO dominio | COMPLETADA | Se verificó/creó DTOs de dominio raíz + anidados desde SOAP (incluyendo header/body/error cuando existan) en archivos separados. |
| F5-Garantía rutas request/response | COMPLETADA | Se verificó creación de DTOs técnicos completos y clases SoapBody<Servicio>Request/Response en infrastructure/output/adapter/request y response. |
| F6-Garantía excepción XML en domain | COMPLETADA | Se verificó/creó XmlConverterException en domain/exception para manejo de errores XML. |
| F7-Garantía XmlConverter en infrastructure | COMPLETADA | Se verificó/actualizó XmlConverter en infrastructure/output/adapter/converter para manejo reactivo de XML. |
| F8-Garantía SoapWebClientExecutor en infrastructure | COMPLETADA | Se verificó/actualizó SoapWebClientExecutor en infrastructure/output/adapter/excecutor para ejecución SOAP vía WebClient. |
| F9-Garantía SoapBuilder SOAP en infrastructure | COMPLETADA | Se verificó/actualizó builder SOAP con patrón MapStruct en infrastructure/output/adapter/builder. |
| F10-Validación application.yml webclient | COMPLETADA | Configuración validada: webclient.wsClientes0024.base-url/path/timeout-ms sin valores por defecto. |
| F11-Validación variables Helm webclient | CON_ADVERTENCIAS | Faltan variables Helm requeridas: helm/dev.yml: WS_CLIENTES_0024_BASE_URL, WS_CLIENTES_0024_PATH, WS_CLIENTES_0024_TIMEOUT_MS \| helm/test.yml: WS_CLIENTES_0024_BASE_URL, WS_CLIENTES_0024_PATH, WS_CLIENTES_0024_TIMEOUT_MS \| helm/prod.yml: WS_CLIENTES_0024_BASE_URL, WS_CLIENTES_0024_PATH, WS_CLIENTES_0024_TIMEOUT_MS |
| F12-Garantía PortOutput con DTO dominio | COMPLETADA | Se verificó/actualizó PortOutput con DTOs de dominio por servicio/operación y firma reactiva execute(RequestDto). |
| F13-Garantía SoapBodyRequest input | CON_ADVERTENCIAS | Se verificó/actualizó SoapBodyRequest en infrastructure.input.adapter.rest.dto.request con tipos com.pichincha.sp.generated.*. |
| F14-Garantía SoapEnvelopeRequest input | COMPLETADA | Se verificó/actualizó SoapEnvelopeRequest en infrastructure.input.adapter.rest.dto.request reutilizando SoapBodyRequest. |
| F15-Garantía SoapBodyResponse input | CON_ADVERTENCIAS | Se verificó/actualizó SoapBodyResponse en infrastructure.input.adapter.rest.dto.response con tipos com.pichincha.sp.generated.*Response. |
| F16-Garantía SoapEnvelopeResponse input | COMPLETADA | Se verificó/actualizó SoapEnvelopeResponse en infrastructure.input.adapter.rest.dto.response reutilizando SoapBodyResponse. |
| F17-Garantía SoapFaultBodyDto input | COMPLETADA | Se verificó/actualizó SoapFaultBodyDto en infrastructure.input.adapter.rest.dto. |
| F18-Garantía SoapBuilder input | COMPLETADA | Se verificó/actualizó builder MapStruct en infrastructure.input.adapter.rest.builder usando clases generated. |
| F19-Checklist final | COMPLETADA | Checklist generado en .plugin-validator/reports/checklist-generacion-wsclientes0024-20260611-102055.md. |

## Plan orquestador usado
# Orquestador de generación SOAP por fases

Este archivo define el plan maestro que debe seguir el generador para producir artefactos reutilizables y consistentes.

## Fase 1: Generación base
- Objetivo: crear artefactos iniciales de domain/application/infrastructure según plantilla.
- Entradas: nombre del servicio, URL, request SOAP, response SOAP.
- Resultado esperado: archivos mínimos creados para completar la integración.

## Fase 2: Normalización DTO
- Objetivo: validar estructura DTO contra XML request/response y corregir inconsistencias.
- Reglas:
  - mantener campos/nodos requeridos,
  - ajustar tipos/estructura cuando estén incompletos,
  - mantener separación por capas.

## Fase 3: Split y reutilización DTO
- Objetivo: garantizar reutilización y evitar duplicados.
- Reglas:
  - un DTO por archivo,
  - no DTOs anidados para modelos reutilizables,
  - reutilizar DTOs genéricos (`Header`, `Body`, `Bancs`, `SoapEnvelope`, `SoapHeader`, `SoapBody`) si ya existen.

## Fase 4: Garantía de rutas técnicas
- Objetivo: asegurar creación de DTO técnicos en rutas obligatorias.
- Rutas obligatorias:
  - `com.pichincha.sp.infrastructure.output.adapter.request`
  - `com.pichincha.sp.infrastructure.output.adapter.response`

## Fase 5: Verificación y reportes
- Objetivo: consolidar evidencia de ejecución y estado.
- Salidas obligatorias:
  - checklist de generación,
  - reporte de orquestación por fases (estado por fase y detalles),
  - resumen de cambios aplicados.
