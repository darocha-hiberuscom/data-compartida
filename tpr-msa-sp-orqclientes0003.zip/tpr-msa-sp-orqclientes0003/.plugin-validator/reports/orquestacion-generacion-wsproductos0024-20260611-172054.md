# Orquestación de generación SOAP por fases

- Tipo de servicio: SOAP
- Servicio: WsProductos0024
- URL: https://tpr-msa-sp-wsproductos0024-enp.apps.ocptest.uiotest.bpichinchatest.test/WSProductos0024Request
- Fecha: 2026-06-11T22:20:54.754Z

## Resultado por fase
| Fase | Estado | Detalle |
| --- | --- | --- |
| F1-Generación base | COMPLETADA | Generación SOAP completa para WsProductos0024 ConsultarDescripcionTodosProductos01: domain DTOs (bodyIn/bodyOut), port output, adapter con SoapWebClientExecutor, builder MapStruct, mapper MapStruct, DTOs técnicos JAXB request/response, application.yml y Helm actualizados. |
| F2-Normalización DTO | COMPLETADA | Normalización completa de DTOs y artefactos SOAP para WsProductos0024 (ConsultarDescripcionTodosProductos01): domain DTOs bodyIn/bodyOut, DTOs técnicos JAXB request/response en rutas obligatorias, port output, adapter con SoapWebClientExecutor, builder, mapper, application.yml y Helm actualizados. |
| F3-Split y reutilización DTO | COMPLETADA | Generación SOAP completa para WsProductos0024: DTOs dominio (bodyIn/bodyOut), port output, adapter con SoapWebClientExecutor, builder, mapper, DTOs técnicos JAXB request/response en rutas obligatorias, reutilización de DTOs comunes existentes. |
| F4-Garantía DTO dominio | COMPLETADA | Se verificó/creó DTOs de dominio raíz + anidados desde SOAP (incluyendo header/body/error cuando existan) en archivos separados. |
| F5-Garantía rutas request/response | COMPLETADA | Se verificó creación de DTOs técnicos completos y clases SoapBody<Servicio>Request/Response en infrastructure/output/adapter/request y response. |
| F6-Garantía excepción XML en domain | COMPLETADA | Se verificó/creó XmlConverterException en domain/exception para manejo de errores XML. |
| F7-Garantía XmlConverter en infrastructure | CON_ADVERTENCIAS | Se verificó/actualizó XmlConverter en infrastructure/output/adapter/converter para manejo reactivo de XML. |
| F8-Garantía SoapWebClientExecutor en infrastructure | COMPLETADA | Se verificó/actualizó SoapWebClientExecutor en infrastructure/output/adapter/excecutor para ejecución SOAP vía WebClient. |
| F9-Garantía SoapBuilder SOAP en infrastructure | COMPLETADA | Se verificó/actualizó builder SOAP con patrón MapStruct en infrastructure/output/adapter/builder. |
| F10-Mapper SOAP (conversión response → DTO dominio) | CON_ADVERTENCIAS | Mapper SOAP ya existe con anotación y método toDomainResponse esperado |
| F11-OutputAdapter (orquestación completa) | COMPLETADA | Adapter actualizado: SoapWebClientExecutor.execute(uri, buildSoapRequest, envelope.class, properties) → responseBuilder.buildResponse |
| F12-Validación application.yml webclient | CON_ADVERTENCIAS | Faltan propiedades en application.yml para webclient.wsProductos0024: uri, read-timeout, http-headers. |
| F13-Validación variables Helm webclient | COMPLETADA | Variables WS_PRODUCTOS_0024_URI, WS_PRODUCTOS_0024_READ_TIMEOUT inyectadas en: helm/dev.yml, helm/test.yml, helm/prod.yml. |
| F14-Garantía PortOutput con DTO dominio | CON_ADVERTENCIAS | Se verificó/actualizó PortOutput con DTOs de dominio por servicio/operación y firma reactiva execute(RequestDto). |
| F15-Garantía SoapBodyRequest input | CON_ADVERTENCIAS | Se verificó/actualizó SoapBodyRequest en infrastructure.input.adapter.rest.dto.request con tipos com.pichincha.sp.generated.*. |
| F16-Garantía SoapEnvelopeRequest input | COMPLETADA | Se verificó/actualizó SoapEnvelopeRequest en infrastructure.input.adapter.rest.dto.request reutilizando SoapBodyRequest. |
| F17-Garantía SoapBodyResponse input | CON_ADVERTENCIAS | Se verificó/actualizó SoapBodyResponse en infrastructure.input.adapter.rest.dto.response con tipos com.pichincha.sp.generated.*Response. |
| F18-Garantía SoapEnvelopeResponse input | COMPLETADA | Se verificó/actualizó SoapEnvelopeResponse en infrastructure.input.adapter.rest.dto.response reutilizando SoapBodyResponse. |
| F19-Garantía SoapFaultBodyDto input | COMPLETADA | Se verificó/actualizó SoapFaultBodyDto en infrastructure.input.adapter.rest.dto. |
| F20-Garantía SoapBuilder input | COMPLETADA | Se verificó/actualizó builder MapStruct en infrastructure.input.adapter.rest.builder usando clases generated. |
| F21-Checklist final | COMPLETADA | Checklist generado en .plugin-validator/reports/checklist-generacion-wsproductos0024-20260611-172054.md. |

## Plan orquestador usado
# Orquestador de generación SOAP por fases

Este archivo define el plan maestro que debe seguir el generador para producir artefactos reutilizables y consistentes.

## Fase 1: Generación base
- Objetivo: crear artefactos iniciales de domain/application/infrastructure según plantilla.
- Entradas: nombre del servicio, URL, request SOAP, response SOAP.
- Resultado esperado: archivos mínimos creados para completar la integración.

## Fase 2: Normalización DTO
- Objetivo: validar estructura DTO contra XML request/response y corregir inconsistencias.
- Reglas:
  - mantener campos/nodos requeridos,
  - ajustar tipos/estructura cuando estén incompletos,
  - mantener separación por capas.

## Fase 3: Split y reutilización DTO
- Objetivo: garantizar reutilización y evitar duplicados.
- Reglas:
  - un DTO por archivo,
  - no DTOs anidados para modelos reutilizables,
  - reutilizar DTOs genéricos (`Header`, `Body`, `Bancs`, `SoapEnvelope`, `SoapHeader`, `SoapBody`) si ya existen.

## Fase 4: Garantía de rutas técnicas
- Objetivo: asegurar creación de DTO técnicos en rutas obligatorias.
- Rutas obligatorias:
  - `com.pichincha.sp.infrastructure.output.adapter.request`
  - `com.pichincha.sp.infrastructure.output.adapter.response`

## Fase 5: Verificación y reportes
- Objetivo: consolidar evidencia de ejecución y estado.
- Salidas obligatorias:
  - checklist de generación,
  - reporte de orquestación por fases (estado por fase y detalles),
  - resumen de cambios aplicados.
