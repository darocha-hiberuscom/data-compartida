package com.pichincha.sp.domain.dto;

public record WsProductos0024RequestDto(
    HeaderInDto headerIn,
    WsProductos0024RequestBodyInDto bodyIn
) {
}