package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsClientes0024ConsultarIdentificacion01ResponseResponse(
    WsClientes0024ConsultarIdentificacion01ResponseHeaderOutResponse headerOut,
    WsClientes0024ConsultarIdentificacion01ResponseBodyOutResponse bodyOut,
    WsClientes0024ConsultarIdentificacion01ResponseErrorResponse error
) {
}