package com.pichincha.sp.domain.dto;

public record WsProductos0024ResponseProductoDto(
    String cif,
    String numero,
    String principal,
    String tipo,
    String idProducto,
    String descripcion,
    String subtipo
) {
}