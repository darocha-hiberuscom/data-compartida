package com.pichincha.sp.domain.dto;

public record OrquestadorRequestDto(
        OrquestadorHeaderInDto headerIn,
        OrquestadorBodyInDto bodyIn) {
}