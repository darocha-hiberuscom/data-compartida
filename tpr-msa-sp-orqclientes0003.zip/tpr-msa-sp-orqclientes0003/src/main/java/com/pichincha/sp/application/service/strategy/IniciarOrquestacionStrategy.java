package com.pichincha.sp.application.service.strategy;

import com.pichincha.sp.application.port.output.ConsultaCifPortOutput;
import com.pichincha.sp.application.port.output.ConsultarAliasPortOutput;
import com.pichincha.sp.application.port.output.ConsultarCuentasPortOutput;
import com.pichincha.sp.application.port.output.ConsultarPrestamosPortOutput;
import com.pichincha.sp.application.port.output.ConsultarTarjetasPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0002RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0003RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0114RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class IniciarOrquestacionStrategy implements OrquestacionStrategy {

    private final ConsultaCifPortOutput consultaCifPortOutput;
    private final ConsultarAliasPortOutput consultarAliasPortOutput;
    private final ConsultarCuentasPortOutput consultarCuentasPortOutput;
    private final ConsultarPrestamosPortOutput consultarPrestamosPortOutput;
    private final ConsultarTarjetasPortOutput consultarTarjetasPortOutput;

    public IniciarOrquestacionStrategy(
            ConsultaCifPortOutput consultaCifPortOutput,
            ConsultarAliasPortOutput consultarAliasPortOutput,
            ConsultarCuentasPortOutput consultarCuentasPortOutput,
            ConsultarPrestamosPortOutput consultarPrestamosPortOutput,
            ConsultarTarjetasPortOutput consultarTarjetasPortOutput) {
        this.consultaCifPortOutput = consultaCifPortOutput;
        this.consultarAliasPortOutput = consultarAliasPortOutput;
        this.consultarCuentasPortOutput = consultarCuentasPortOutput;
        this.consultarPrestamosPortOutput = consultarPrestamosPortOutput;
        this.consultarTarjetasPortOutput = consultarTarjetasPortOutput;
    }

    @Override
    public boolean supports(String estado) {
        return "iniciar".equalsIgnoreCase(estado);
    }

    @Override
    public Mono<OrquestadorResponseDto> execute(OrquestadorRequestDto request) {
        Mono<String> cifMono = Mono.justOrEmpty(request.bodyIn().cif())
                .filter(cif -> !cif.isBlank() && !"0".equals(cif))
                .switchIfEmpty(consultaCifPortOutput.execute(new WsClientes0024RequestDto(
                        request.bodyIn().identificacion(), request.bodyIn().tipoIdentificacion()))
                        .map(response -> response.bodyOut() == null ? null : response.bodyOut().cif()));

        return cifMono.flatMap(cif -> consultarAliasPortOutput.execute(
                        new WsProductos0024RequestDto(new WsProductos0024RequestDto.OrdenanteDto(cif))))
                .then(consultarCuentasPortOutput.execute(new WsClientes0114RequestDto(
                        request.bodyIn().cif(),
                        request.bodyIn().identificacion(),
                        request.bodyIn().tipoIdentificacion(),
                        request.bodyIn().tipoProducto(),
                        new WsClientes0114RequestDto.CanalDto(null, null))))
                .then(consultarPrestamosPortOutput.execute(new WsClientes0002RequestDto(
                        request.bodyIn().identificacion(), request.bodyIn().tipoIdentificacion())))
                .then(consultarTarjetasPortOutput.execute(new WsClientes0003RequestDto(
                        request.bodyIn().identificacion(), request.bodyIn().tipoIdentificacion())))
                .map(ignored -> successResponse());
    }

    private OrquestadorResponseDto successResponse() {
        return new OrquestadorResponseDto(
                null,
                null,
                null);
    }
}
