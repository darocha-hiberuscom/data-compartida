package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsProductos0024ConsultarDescripcionTodosProductos01ResponseDocumentoResponse(
    String fechaContable,
    String numeroDocumento
) {
}
