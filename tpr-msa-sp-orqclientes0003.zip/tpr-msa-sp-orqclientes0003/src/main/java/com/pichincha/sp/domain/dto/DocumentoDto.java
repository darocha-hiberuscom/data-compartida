package com.pichincha.sp.domain.dto;

public record DocumentoDto(
    String fechaContable,
    String numeroDocumento
) {
}