package com.pichincha.sp.domain.dto;

public record OrquestadorErrorDto(
        String codigo,
        String mensaje,
        String tipo,
        String mensajeNegocio,
        String recurso,
        String componente,
        String backend) {
}