package com.pichincha.sp.domain.dto;

public record WsClientes0024RequestBodyInDto(
    String identificacion,
    String tipoIdentificacion
) {
}