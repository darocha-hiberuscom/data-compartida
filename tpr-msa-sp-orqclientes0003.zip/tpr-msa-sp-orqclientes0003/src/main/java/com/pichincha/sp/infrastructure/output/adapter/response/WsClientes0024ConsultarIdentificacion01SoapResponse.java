package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsClientes0024ConsultarIdentificacion01SoapResponse(
    String payloadXml
) {
    public static WsClientes0024ConsultarIdentificacion01SoapResponse fromXml(String payloadXml) {
        return new WsClientes0024ConsultarIdentificacion01SoapResponse(payloadXml);
    }

    public static WsClientes0024ConsultarIdentificacion01SoapResponse sample() {
        return new WsClientes0024ConsultarIdentificacion01SoapResponse("""
<?xml version="1.0" encoding="UTF-8"?> <S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">   <S:Body>     <ns2:ConsultarIdentificacion01Response xmlns:ns2="http://bpichincha.com/servicios">       <headerOut>         <dispositivo>5CiD3iOF8whuBQEqbct1tlD2mAuclrM=</dispositivo>         <empresa>0010</empresa>         <canal>02</canal>         <medio>020002</medio>         <aplicacion>00270</aplicacion>         <agencia>00012</agencia>         <tipoTransaccion>304100111</tipoTransaccion>         <usuario>USINTERT</usuario>         <guid>550e8400e29b41d4a716446655440000</guid>         <fechaHora>201608161239203000</fechaHora>         <sesion>ASDASD77R01YH</sesion>         <documento>           <fechaContable>20260320</fechaContable>           <numeroDocumento>000000001</numeroDocumento>         </documento>       </headerOut>       <bodyOut>         <CIF>3860119</CIF>         <identificacion>0602119182</identificacion>         <tipoIdentificacion>0001</tipoIdentificacion>         <nombre>CAISATASIG TORANZO DE CARCHIPULLA</nombre>         <direccion>Amazonas 4545, Pereira,</direccion>         <tipoCliente>01</tipoCliente>         <estado>000</estado>       </bodyOut>       <error>         <codigo>0</codigo>         <mensaje>OK</mensaje>         <mensajeNegocio>Consulta exitosa</mensajeNegocio>         <tipo>INFO</tipo>         <recurso>WSClientes0024/ConsultarIdentificacion01</recurso>         <componente>ConsultarIdentificacion01</componente>         <backend>00000</backend>       </error>     </ns2:ConsultarIdentificacion01Response>   </S:Body> </S:Envelope>
""");
    }
}