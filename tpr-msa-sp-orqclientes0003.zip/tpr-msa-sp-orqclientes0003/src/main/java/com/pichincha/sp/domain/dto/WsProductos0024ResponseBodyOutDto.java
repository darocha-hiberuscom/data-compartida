package com.pichincha.sp.domain.dto;

public record WsProductos0024ResponseBodyOutDto(
    WsProductos0024ResponseProductosDto productos
) {
}