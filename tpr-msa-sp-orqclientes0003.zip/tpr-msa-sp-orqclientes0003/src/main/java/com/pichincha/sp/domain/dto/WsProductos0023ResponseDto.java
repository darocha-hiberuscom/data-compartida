package com.pichincha.sp.domain.dto;

import java.util.List;

public record WsProductos0023ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            ProductosDto productos) {
    }

    public record ProductosDto(
            List<ProductoDto> producto) {
    }

    public record ProductoDto(
            String tipo,
            AtributosDto atributos) {
    }

    public record AtributosDto(
            List<AtributoDto> atributo) {
    }

    public record AtributoDto(
            String nombre,
            Boolean valor,
            String descripcion) {
    }
}
