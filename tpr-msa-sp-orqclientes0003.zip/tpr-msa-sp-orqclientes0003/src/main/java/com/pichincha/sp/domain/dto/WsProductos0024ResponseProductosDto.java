package com.pichincha.sp.domain.dto;

public record WsProductos0024ResponseProductosDto(
    WsProductos0024ResponseProductoDto producto
) {
}