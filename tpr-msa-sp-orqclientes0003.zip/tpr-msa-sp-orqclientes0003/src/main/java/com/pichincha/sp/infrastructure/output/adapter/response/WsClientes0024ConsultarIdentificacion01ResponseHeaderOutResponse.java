package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsClientes0024ConsultarIdentificacion01ResponseHeaderOutResponse(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String agencia,
    String tipoTransaccion,
    String usuario,
    String guid,
    String fechaHora,
    String sesion,
    WsClientes0024ConsultarIdentificacion01ResponseDocumentoResponse documento
) {
}