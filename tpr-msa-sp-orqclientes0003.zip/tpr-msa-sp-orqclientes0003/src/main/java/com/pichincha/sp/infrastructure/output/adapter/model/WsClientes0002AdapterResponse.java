package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0002ResponseDto;

public record WsClientes0002AdapterResponse(WsClientes0002ResponseDto payload) {
}