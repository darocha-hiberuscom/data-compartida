package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0114RequestDto;

public record WsClientes0114AdapterRequest(WsClientes0114RequestDto payload) {
}