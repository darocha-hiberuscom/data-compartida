package com.pichincha.sp.domain.dto;

public record WsClientes0114RequestDto(
        String cif,
        String identificacion,
        String tipoIdentificacion,
        String filtroCuenta,
        CanalDto canal) {

    public record CanalDto(
            String referido,
            String acceso) {
    }
}
