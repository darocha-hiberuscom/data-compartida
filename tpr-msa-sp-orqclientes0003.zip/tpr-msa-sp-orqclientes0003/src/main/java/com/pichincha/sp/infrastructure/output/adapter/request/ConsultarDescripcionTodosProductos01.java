package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class ConsultarDescripcionTodosProductos01 {

    @XmlElement(name = "headerIn")
    private HeaderIn headerIn;

    @XmlElement(name = "bodyIn")
    private BodyInWsProductos0024 bodyIn;
}
