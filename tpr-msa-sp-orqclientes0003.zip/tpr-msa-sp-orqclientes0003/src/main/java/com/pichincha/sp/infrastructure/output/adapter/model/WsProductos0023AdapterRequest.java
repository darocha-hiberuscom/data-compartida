package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0023RequestDto;

public record WsProductos0023AdapterRequest(WsProductos0023RequestDto payload) {
}