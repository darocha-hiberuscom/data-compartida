package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0023ResponseDto;

public record WsProductos0023AdapterResponse(WsProductos0023ResponseDto payload) {
}