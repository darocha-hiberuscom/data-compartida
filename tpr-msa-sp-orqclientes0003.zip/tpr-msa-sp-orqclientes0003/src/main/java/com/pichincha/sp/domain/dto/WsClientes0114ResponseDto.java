package com.pichincha.sp.domain.dto;

import java.util.List;

public record WsClientes0114ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            CuentasDto cuentas) {
    }

    public record CuentasDto(
            CorrientesDto corrientes,
            AhorrosDto ahorros,
            InversionesDto inversiones) {
    }

    public record CorrientesDto(
            List<OrquestadorResponseDto.InformacionCorrienteDto> corriente) {
    }

    public record AhorrosDto(
            List<OrquestadorResponseDto.InformacionAhorroDto> ahorro) {
    }

    public record InversionesDto(
            List<OrquestadorResponseDto.InformacionInversionDto> inversion) {
    }
}
