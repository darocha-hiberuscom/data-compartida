package com.pichincha.sp.domain.dto;

public record WsClientes0002RequestDto(
        String identificacion,
        String tipoIdentificacion) {
}
