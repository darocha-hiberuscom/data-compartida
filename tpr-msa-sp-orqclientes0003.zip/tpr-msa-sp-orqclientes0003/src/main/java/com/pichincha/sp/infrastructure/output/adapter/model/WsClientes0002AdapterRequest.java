package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0002RequestDto;

public record WsClientes0002AdapterRequest(WsClientes0002RequestDto payload) {
}