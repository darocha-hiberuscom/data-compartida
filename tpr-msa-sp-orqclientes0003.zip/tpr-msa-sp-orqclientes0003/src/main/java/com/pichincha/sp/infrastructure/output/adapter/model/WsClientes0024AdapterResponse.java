package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;

public record WsClientes0024AdapterResponse(WsClientes0024ResponseDto payload) {
}