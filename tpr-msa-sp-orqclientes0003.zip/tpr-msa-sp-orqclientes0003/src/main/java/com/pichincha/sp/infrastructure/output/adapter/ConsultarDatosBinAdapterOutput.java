package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarDatosBinPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0123RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0123ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0123AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarDatosBinAdapterOutput implements ConsultarDatosBinPortOutput {

    @Qualifier("wsProductos0123WebClient")
    private final WebClient wsProductos0123WebClient;
        private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsProductos0123ResponseDto> execute(WsProductos0123RequestDto request) {
        return wsProductos0123WebClient.post()
                .uri("/")
                .bodyValue(outputAdapterMapper.toWsProductos0123Request(request))
                .retrieve()
                .toBodilessEntity()
                .map(ignored -> outputAdapterMapper.toWsProductos0123Response(new WsProductos0123AdapterResponse(
                        new WsProductos0123ResponseDto(
                                new WsProductos0123ResponseDto.BodyOutDto(
                                        new WsProductos0123ResponseDto.ProductoCreditoDto(null, null, null, null)),
                                new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultarDatosBinAdapterOutput"));
    }
}
