package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyWsClientes0024Request {

    @XmlElement(name = "ConsultarIdentificacion01", namespace = "http://bpichincha.com/servicios")
    private ConsultarIdentificacion01 consultarIdentificacion01;

    public void setConsultarIdentificacion01(ConsultarIdentificacion01 consultarIdentificacion01) {
        this.consultarIdentificacion01 = consultarIdentificacion01;
    }
}
