package com.pichincha.sp.application.service.strategy;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class OrquestacionStrategyResolver {

    private final List<OrquestacionStrategy> strategies;

    public OrquestacionStrategyResolver(List<OrquestacionStrategy> strategies) {
        this.strategies = strategies;
    }

    public OrquestacionStrategy resolve(String estado) {
        return strategies.stream()
                .filter(strategy -> strategy.supports(estado))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("No strategy available for estado=" + estado));
    }
}
