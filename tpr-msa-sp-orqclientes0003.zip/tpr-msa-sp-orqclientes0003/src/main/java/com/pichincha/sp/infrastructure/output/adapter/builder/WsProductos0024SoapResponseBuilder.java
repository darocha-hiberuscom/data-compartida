package com.pichincha.sp.infrastructure.output.adapter.builder;

import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.mapper.WsProductos0024SoapMapper;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapEnvelopeWsProductos0024Response;
import org.springframework.stereotype.Component;

@Component
public class WsProductos0024SoapResponseBuilder {

    private final WsProductos0024SoapMapper mapper;

    public WsProductos0024SoapResponseBuilder(WsProductos0024SoapMapper mapper) {
        this.mapper = mapper;
    }

    public WsProductos0024ResponseDto toDomainResponse(SoapEnvelopeWsProductos0024Response envelope) {
        return mapper.toDomainResponse(envelope);
    }

    public WsProductos0024ResponseDto buildResponse(WsProductos0024RequestDto requestDto, SoapEnvelopeWsProductos0024Response envelope) {
        return mapper.toDomainResponse(envelope);
    }
}
