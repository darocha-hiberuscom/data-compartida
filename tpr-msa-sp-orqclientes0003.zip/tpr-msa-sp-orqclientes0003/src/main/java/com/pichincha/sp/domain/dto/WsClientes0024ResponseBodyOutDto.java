package com.pichincha.sp.domain.dto;

public record WsClientes0024ResponseBodyOutDto(
    String cIF,
    String identificacion,
    String tipoIdentificacion,
    String nombre,
    String direccion,
    String tipoCliente,
    String estado
) {
}