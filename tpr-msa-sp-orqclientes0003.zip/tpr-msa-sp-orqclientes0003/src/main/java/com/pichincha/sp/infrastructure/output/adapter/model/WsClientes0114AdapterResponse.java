package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0114ResponseDto;

public record WsClientes0114AdapterResponse(WsClientes0114ResponseDto payload) {
}