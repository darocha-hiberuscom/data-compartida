package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsProductos0024ConsultarDescripcionTodosProductos01ResponseHeaderOutResponse(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String tipoTransaccion,
    String geolocalizacion,
    String usuario,
    String unicidad,
    String guid,
    String fechaHora,
    String idioma,
    String ip,
    WsProductos0024ConsultarDescripcionTodosProductos01ResponseDocumentoResponse documento
) {
}