package com.pichincha.sp.application.service.strategy;

import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import reactor.core.publisher.Mono;

public interface OrquestacionStrategy {
    boolean supports(String estado);

    Mono<OrquestadorResponseDto> execute(OrquestadorRequestDto request);
}
