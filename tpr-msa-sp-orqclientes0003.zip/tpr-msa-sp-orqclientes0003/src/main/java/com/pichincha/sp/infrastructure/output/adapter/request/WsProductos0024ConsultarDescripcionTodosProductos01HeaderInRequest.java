package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsProductos0024ConsultarDescripcionTodosProductos01HeaderInRequest(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String agencia,
    String tipoTransaccion,
    String geolocalizacion,
    String usuario,
    String unicidad,
    String guid,
    String fechaHora,
    String filler,
    String idioma,
    String sesion,
    String ip,
    String idCliente,
    String tipoIdCliente,
    WsProductos0024ConsultarDescripcionTodosProductos01DocumentoRequest documento
) {
}