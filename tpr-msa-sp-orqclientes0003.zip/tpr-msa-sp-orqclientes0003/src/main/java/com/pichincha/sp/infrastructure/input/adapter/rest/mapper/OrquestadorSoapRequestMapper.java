package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrquestadorSoapRequestMapper {
    OrquestadorRequestDto toDomain(OrquestadorRequestDto request);
}
