package com.pichincha.sp.domain.dto;

public record ErrorDto(
    String codigo,
    String mensaje,
    String mensajeNegocio,
    String tipo,
    String recurso,
    String componente,
    String backend
) {
}