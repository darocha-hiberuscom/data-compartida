package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultaConfiguracionProductoPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0023RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0023ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0023AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultaConfiguracionProductoAdapterOutput implements ConsultaConfiguracionProductoPortOutput {

    @Qualifier("wsProductos0023WebClient")
    private final WebClient wsProductos0023WebClient;
    private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsProductos0023ResponseDto> execute(WsProductos0023RequestDto request) {
        return wsProductos0023WebClient.post()
                .uri("/")
            .bodyValue(outputAdapterMapper.toWsProductos0023Request(request))
                .retrieve()
                .toBodilessEntity()
            .map(ignored -> outputAdapterMapper.toWsProductos0023Response(new WsProductos0023AdapterResponse(
                new WsProductos0023ResponseDto(
                    new WsProductos0023ResponseDto.BodyOutDto(new WsProductos0023ResponseDto.ProductosDto(java.util.List.of())),
                    new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultaConfiguracionProductoAdapterOutput"));
    }
}
