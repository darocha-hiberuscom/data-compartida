package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsProductos0024ConsultarDescripcionTodosProductos01SoapRequest(
    String payloadXml
) {
    public static WsProductos0024ConsultarDescripcionTodosProductos01SoapRequest fromXml(String payloadXml) {
        return new WsProductos0024ConsultarDescripcionTodosProductos01SoapRequest(payloadXml);
    }

    public static WsProductos0024ConsultarDescripcionTodosProductos01SoapRequest sample() {
        return new WsProductos0024ConsultarDescripcionTodosProductos01SoapRequest("""
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://bpichincha.com/servicios">    <soapenv:Header/>    <soapenv:Body> 	  <ser:ConsultarDescripcionTodosProductos01> 		 <headerIn> 			<dispositivo>IOS-5715AA94-B1A4-45C6-9088-D53330DDC932</dispositivo> 			<empresa>0010</empresa> 			<canal>03</canal> 			<medio>030006</medio> 			<aplicacion>00663</aplicacion> 			<agencia></agencia> 			<tipoTransaccion>202002401</tipoTransaccion> 			<geolocalizacion>1234</geolocalizacion> 			<usuario>USINTERT</usuario> 			<unicidad>e7eaa2eb-b703-4cd5-89be-ada1b91d6dbb</unicidad> 			<guid>e7eaa2eb-b703-4cd5-89be-ada1b91d6dbb</guid> 			<fechaHora>202604160955000624</fechaHora> 			<filler></filler> 			<idioma>es-EC</idioma> 			<sesion></sesion> 			<ip>10.151.152.108</ip> 			<idCliente></idCliente> 			<tipoIdCliente></tipoIdCliente> 			<documento> 			   <fechaContable></fechaContable> 			   <numeroDocumento></numeroDocumento> 			   <journals></journals> 			</documento> 		 </headerIn>          		 <bodyIn> 			<ordenante> 			   <cif>0000000001522146</cif> 			</ordenante> 		 </bodyIn> 	  </ser:ConsultarDescripcionTodosProductos01>    </soapenv:Body> </soapenv:Envelope>
""");
    }
}