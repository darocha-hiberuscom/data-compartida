package com.pichincha.sp.infrastructure.input.adapter.rest.presenter;

import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import org.springframework.stereotype.Component;

@Component
public class OrquestadorPresenter {

    public OrquestadorResponseDto buildFunctionalError(BusinessException exception) {
        return new OrquestadorResponseDto(
                new OrquestadorResponseDto.GenericHeaderOutDto(exception.getCode(), exception.getMessage()),
                null,
                new OrquestadorResponseDto.GenericErrorDto(exception.getCode(), exception.getMessage(), "ERROR"));
    }

    public OrquestadorResponseDto buildGenericFault() {
        return new OrquestadorResponseDto(
                new OrquestadorResponseDto.GenericHeaderOutDto("500", "Unexpected error"),
                null,
                new OrquestadorResponseDto.GenericErrorDto("500", "Unexpected error", "ERROR"));
    }
}
