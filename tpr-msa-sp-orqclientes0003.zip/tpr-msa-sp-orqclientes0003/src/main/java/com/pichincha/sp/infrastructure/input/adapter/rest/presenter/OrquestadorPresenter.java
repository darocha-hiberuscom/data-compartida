package com.pichincha.sp.infrastructure.input.adapter.rest.presenter;

import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.OrquestadorErrorDto;
import com.pichincha.sp.domain.dto.OrquestadorHeaderOutDto;
import com.pichincha.sp.domain.exception.BusinessException;
import org.springframework.stereotype.Component;

@Component
public class OrquestadorPresenter {

    public OrquestadorResponseDto buildFunctionalError(BusinessException exception) {
        return new OrquestadorResponseDto(
                new OrquestadorHeaderOutDto(null, null, null, null),
                null,
                new OrquestadorErrorDto(exception.getCode(), exception.getMessage(), "ERROR", null, null, null, null));
    }

    public OrquestadorResponseDto buildGenericFault() {
        return new OrquestadorResponseDto(
                new OrquestadorHeaderOutDto(null, null, null, null),
                null,
                new OrquestadorErrorDto("500", "Unexpected error", "ERROR", null, null, null, null));
    }
}
