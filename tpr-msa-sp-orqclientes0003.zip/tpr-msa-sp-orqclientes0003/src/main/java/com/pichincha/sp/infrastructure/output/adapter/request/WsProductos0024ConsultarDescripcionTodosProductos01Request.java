package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsProductos0024ConsultarDescripcionTodosProductos01Request(
    WsProductos0024ConsultarDescripcionTodosProductos01HeaderInRequest headerIn,
    WsProductos0024ConsultarDescripcionTodosProductos01BodyInRequest bodyIn
) {
}