package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import reactor.core.publisher.Mono;

public interface WsProductos0024PortOutput {
    Mono<WsProductos0024ResponseDto> execute(WsProductos0024RequestDto request);
}
