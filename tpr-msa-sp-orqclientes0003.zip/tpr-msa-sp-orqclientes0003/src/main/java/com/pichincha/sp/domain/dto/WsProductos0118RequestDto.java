package com.pichincha.sp.domain.dto;

public record WsProductos0118RequestDto(
        String identificacion) {
}
