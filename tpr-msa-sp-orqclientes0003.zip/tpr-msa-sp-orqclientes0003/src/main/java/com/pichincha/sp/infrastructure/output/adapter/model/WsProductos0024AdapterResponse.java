package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;

public record WsProductos0024AdapterResponse(WsProductos0024ResponseDto payload) {
}