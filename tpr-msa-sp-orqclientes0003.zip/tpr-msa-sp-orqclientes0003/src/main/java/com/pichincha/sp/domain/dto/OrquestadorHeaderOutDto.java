package com.pichincha.sp.domain.dto;

public record OrquestadorHeaderOutDto(
        String canal,
        String medio,
        String aplicacion,
        String guid) {
}