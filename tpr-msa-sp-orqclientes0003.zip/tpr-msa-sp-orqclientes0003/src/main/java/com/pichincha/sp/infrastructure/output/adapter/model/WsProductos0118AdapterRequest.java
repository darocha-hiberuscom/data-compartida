package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0118RequestDto;

public record WsProductos0118AdapterRequest(WsProductos0118RequestDto payload) {
}