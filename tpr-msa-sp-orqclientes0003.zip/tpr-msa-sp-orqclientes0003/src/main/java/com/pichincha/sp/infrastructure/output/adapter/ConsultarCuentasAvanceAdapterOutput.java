package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarCuentasAvancePortOutput;
import com.pichincha.sp.domain.dto.WsClientes0114RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0114ResponseDto;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class ConsultarCuentasAvanceAdapterOutput implements ConsultarCuentasAvancePortOutput {

    private final ConsultarCuentasAdapterOutput delegator;

    public ConsultarCuentasAvanceAdapterOutput(ConsultarCuentasAdapterOutput delegator) {
        this.delegator = delegator;
    }

    @Override
    public Mono<WsClientes0114ResponseDto> execute(WsClientes0114RequestDto request) {
        return delegator.execute(request);
    }
}
