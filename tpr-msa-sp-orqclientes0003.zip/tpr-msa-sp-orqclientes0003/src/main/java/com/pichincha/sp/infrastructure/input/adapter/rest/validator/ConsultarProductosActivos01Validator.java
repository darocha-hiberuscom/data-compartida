package com.pichincha.sp.infrastructure.input.adapter.rest.validator;

import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.exception.BusinessException;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConsultarProductosActivos01Validator {

    private static final Set<String> TIPO_PRODUCTO_VALIDO = Set.of("T", "CC", "AH", "IV", "TJ", "TJA", "CR", "CAT", "CAC", "CAV");

    private final List<Rule> rules;
    private final String appName;
    private final String backend;

    public ConsultarProductosActivos01Validator(
            @Value("${service-errors.identificacion-invalid-code}") String identificacionCode,
            @Value("${service-errors.identificacion-invalid-message}") String identificacionMessage,
            @Value("${service-errors.tipo-identificacion-invalid-code}") String tipoIdentificacionCode,
            @Value("${service-errors.tipo-identificacion-invalid-message}") String tipoIdentificacionMessage,
            @Value("${service-errors.tipo-producto-invalid-code}") String tipoProductoCode,
            @Value("${service-errors.tipo-producto-invalid-message}") String tipoProductoMessage,
            @Value("${spring.application.name}") String appName,
            @Value("${service-errors.backend}") String backend) {
        this.appName = appName;
        this.backend = backend;
        this.rules = List.of(
                new Rule(
                        req -> isInvalid(req.bodyIn().identificacion()),
                        identificacionCode,
                        identificacionMessage),
                new Rule(
                        req -> isInvalid(req.bodyIn().tipoIdentificacion()),
                        tipoIdentificacionCode,
                        tipoIdentificacionMessage),
                new Rule(
                        req -> !TIPO_PRODUCTO_VALIDO.contains(req.bodyIn().tipoProducto()),
                        tipoProductoCode,
                        tipoProductoMessage));
    }

    public void validate(OrquestadorRequestDto request) {
        if (request == null || request.bodyIn() == null) {
            throw build("1", "Valor del campo identificacion vacio o invalido");
        }
        rules.stream().filter(rule -> rule.predicate().test(request)).findFirst().ifPresent(rule -> {
            throw build(rule.code(), rule.message());
        });
    }

    private BusinessException build(String code, String message) {
        return new BusinessException(code, message, appName + "/ConsultarProductosActivos01", appName, backend);
    }

    private boolean isInvalid(String value) {
        return value == null || value.isBlank() || "0".equals(value);
    }

    private record Rule(Predicate<OrquestadorRequestDto> predicate, String code, String message) {
    }
}
