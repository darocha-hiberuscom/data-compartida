package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsClientes0024ConsultarIdentificacion01SoapRequest(
    String payloadXml
) {
    public static WsClientes0024ConsultarIdentificacion01SoapRequest fromXml(String payloadXml) {
        return new WsClientes0024ConsultarIdentificacion01SoapRequest(payloadXml);
    }

    public static WsClientes0024ConsultarIdentificacion01SoapRequest sample() {
        return new WsClientes0024ConsultarIdentificacion01SoapRequest("""
<soapenv:Envelope     xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"     xmlns:bp="http://bpichincha.com/servicios">     <soapenv:Header/>     <soapenv:Body>       <bp:ConsultarIdentificacion01>         <headerIn>           <dispositivo>5CiD3iOF8whuBQEqbct1tlD2mAuclrM=</dispositivo>           <empresa>0010</empresa>           <canal>02</canal>           <medio>020002</medio>           <aplicacion>00270</aplicacion>           <agencia>00012</agencia>           <tipoTransaccion>304100111</tipoTransaccion>           <geolocalizacion>6588542</geolocalizacion>           <usuario>USINTERT</usuario>           <unicidad>UZhDOa2GXtkAK2/QovFagnnS+nQSGAF/SKyTIIv1axc=</unicidad>           <guid>550e8400e29b41d4a716446655440000</guid>           <fechaHora>201608161239203000</fechaHora>           <filler>00000000000000000000000000000000000000000000000000</filler>           <idioma>es</idioma>           <sesion>ASDASD77R01YH</sesion>           <ip>192.168.123.111</ip>           <idCliente>1711089364</idCliente>           <tipoIdCliente>0001</tipoIdCliente>           <bancs>             <teller>00008002</teller>             <terminal>1</terminal>             <institucion>0010</institucion>             <agencia>0012</agencia>             <estacion>1</estacion>             <aplicacion/>             <canal>0</canal>           </bancs>         </headerIn>         <bodyIn>           <!-- Cédula de identidad (0001), RUC (0002) o Pasaporte (0003) -->           <identificacion>0602119182</identificacion>           <!-- 0001=Cedula | 0002=RUC | 0003=Pasaporte -->           <tipoIdentificacion>0001</tipoIdentificacion>         </bodyIn>       </bp:ConsultarIdentificacion01>     </soapenv:Body> </soapenv:Envelope>
""");
    }
}