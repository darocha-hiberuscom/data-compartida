package com.pichincha.sp.domain.dto;

import java.util.List;

public record AysWsclientes0220ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            DatosTarjetaDto datosTarjeta) {
    }

    public record DatosTarjetaDto(
            List<TarjetaDto> item) {
    }

    public record TarjetaDto(
            String numeroTarjeta,
            String tipoTarjeta,
            String emisor,
            String minimoPagar,
            String totalPagarFecha,
            String fechaProximoPago,
            String saldoTarjeta) {
    }
}
