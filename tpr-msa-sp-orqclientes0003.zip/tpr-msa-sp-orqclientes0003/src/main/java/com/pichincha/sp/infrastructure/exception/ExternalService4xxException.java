package com.pichincha.sp.infrastructure.exception;

public class ExternalService4xxException extends InfrastructureException {

    public ExternalService4xxException(String message, String component) {
        super(message, component);
    }
}
