package com.pichincha.sp.domain.dto;

public record OrquestadorBodyOutDto(
        String codigo,
        String mensaje) {
}