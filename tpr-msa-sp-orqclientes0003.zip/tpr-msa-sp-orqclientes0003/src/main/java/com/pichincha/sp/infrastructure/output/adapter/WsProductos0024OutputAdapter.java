package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.WsProductos0024PortOutput;
import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.builder.WsProductos0024SoapBuilder;
import com.pichincha.sp.infrastructure.output.adapter.builder.WsProductos0024SoapResponseBuilder;
import com.pichincha.sp.infrastructure.output.adapter.excecutor.SoapWebClientExecutor;
import com.pichincha.sp.infrastructure.output.adapter.properties.webclient.WebClientProperties;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapEnvelopeWsProductos0024Response;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class WsProductos0024OutputAdapter implements WsProductos0024PortOutput {

    private final SoapWebClientExecutor executor;
    private final WsProductos0024SoapBuilder builder;
    private final WsProductos0024SoapResponseBuilder responseBuilder;
    private final WebClientProperties webClientProperties;

    public WsProductos0024OutputAdapter(
            SoapWebClientExecutor executor,
            WsProductos0024SoapBuilder builder,
            WsProductos0024SoapResponseBuilder responseBuilder,
            WebClientProperties webClientProperties
    ) {
        this.executor = executor;
        this.builder = builder;
        this.responseBuilder = responseBuilder;
        this.webClientProperties = webClientProperties;
    }

    @Override
    public Mono<WsProductos0024ResponseDto> execute(WsProductos0024RequestDto request) {
        return Mono.just(request)
            .flatMap(requestDto ->
                        executor.execute(
                                webClientProperties.wsProductos0024().uri(),
                                builder.buildSoapRequest(requestDto),
                                SoapEnvelopeWsProductos0024Response.class,
                                webClientProperties.wsProductos0024()
                        )
                    .map(response -> responseBuilder.buildResponse(requestDto, response))
                );
    }
}