package com.pichincha.sp.domain.exception;

public class XmlConverterException extends RuntimeException {

    public XmlConverterException(String message) {
        super(message);
    }

    public XmlConverterException(String message, Throwable cause) {
        super(message, cause);
    }
}