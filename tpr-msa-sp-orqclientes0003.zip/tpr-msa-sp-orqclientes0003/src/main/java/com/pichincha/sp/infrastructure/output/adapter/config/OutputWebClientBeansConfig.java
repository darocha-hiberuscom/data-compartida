package com.pichincha.sp.infrastructure.output.adapter.config;

import com.pichincha.sp.infrastructure.output.adapter.properties.webclient.WebClientProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
@EnableConfigurationProperties(WebClientProperties.class)
public class OutputWebClientBeansConfig extends WebClientConfig {

    @Bean
    public WebClient wsClientes0024WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsClientes0024()).build();
    }

    @Bean
    public WebClient wsProductos0024WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsProductos0024()).build();
    }

    @Bean
    public WebClient wsProductos0023WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsProductos0023()).build();
    }

    @Bean
    public WebClient wsClientes0114WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsClientes0114()).build();
    }

    @Bean
    public WebClient wsClientes0002WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsClientes0002()).build();
    }

    @Bean
    public WebClient aysWsclientes0220WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.aysWsclientes0220()).build();
    }

    @Bean
    public WebClient wsClientes0003WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsClientes0003()).build();
    }

    @Bean
    public WebClient wsProductos0123WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsProductos0123()).build();
    }

    @Bean
    public WebClient wsProductos0118WebClient(WebClientProperties properties) {
        return getWebClientBuilder(properties.wsProductos0118()).build();
    }
}
