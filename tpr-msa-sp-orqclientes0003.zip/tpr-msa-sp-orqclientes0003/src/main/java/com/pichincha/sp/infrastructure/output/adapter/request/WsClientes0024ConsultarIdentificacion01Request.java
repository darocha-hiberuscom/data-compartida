package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsClientes0024ConsultarIdentificacion01Request(
    WsClientes0024ConsultarIdentificacion01HeaderInRequest headerIn,
    WsClientes0024ConsultarIdentificacion01BodyInRequest bodyIn
) {
}