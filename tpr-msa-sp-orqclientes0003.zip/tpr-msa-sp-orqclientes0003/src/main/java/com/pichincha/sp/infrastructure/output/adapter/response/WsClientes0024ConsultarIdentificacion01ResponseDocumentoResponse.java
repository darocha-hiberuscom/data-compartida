package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsClientes0024ConsultarIdentificacion01ResponseDocumentoResponse(
    String fechaContable,
    String numeroDocumento
) {
}