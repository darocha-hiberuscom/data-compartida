package com.pichincha.sp.infrastructure.output.adapter.converter;

import com.pichincha.sp.domain.exception.XmlConverterException;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@RequiredArgsConstructor
public class XmlConverter {

    private final Map<Class<?>, JAXBContext> contextCache =
            new ConcurrentHashMap<>();

    public <T> Mono<String> toXml(T object) {

        return Mono.justOrEmpty(object)

                .switchIfEmpty(Mono.error(
                        new XmlConverterException(
                                "El objeto a convertir no puede ser null"
                        )
                ))

                .flatMap(value ->
                        Mono.fromCallable(() -> {

                                    JAXBContext context =
                                            getContext(value.getClass());

                                    Marshaller marshaller =
                                            context.createMarshaller();

                                    marshaller.setProperty(
                                            Marshaller.JAXB_FORMATTED_OUTPUT,
                                            Boolean.TRUE
                                    );

                                    marshaller.setProperty(
                                            Marshaller.JAXB_FRAGMENT,
                                            Boolean.FALSE
                                    );

                                    StringWriter writer =
                                            new StringWriter();

                                    marshaller.marshal(value, writer);

                                    return writer.toString();

                                })
                                .subscribeOn(Schedulers.boundedElastic())
                )

                .onErrorMap(ex ->
                        ex instanceof XmlConverterException
                                ? ex
                                : new XmlConverterException(
                                "Error convirtiendo objeto a XML",
                                ex
                        )
                );
    }

    public <T> Mono<T> fromXml(
            String xml,
            Class<T> clazz
    ) {

        return Mono.justOrEmpty(xml)

                .filter(value -> !value.isBlank())

                .switchIfEmpty(Mono.error(
                        new XmlConverterException(
                                "El XML no puede ser null o vacío"
                        )
                ))

                .flatMap(value ->
                        Mono.fromCallable(() -> {

                                    JAXBContext context =
                                            getContext(clazz);

                                    Unmarshaller unmarshaller =
                                            context.createUnmarshaller();

                                    Object result =
                                            unmarshaller.unmarshal(
                                                    new StringReader(value)
                                            );

                                    if (clazz.isInstance(result)) {
                                        return clazz.cast(result);
                                    }

                                    if (result instanceof JAXBElement<?> element
                                            && clazz.isInstance(element.getValue())) {

                                        return clazz.cast(element.getValue());
                                    }

                                    throw new XmlConverterException(
                                            "El XML no corresponde al tipo esperado: "
                                                    + clazz.getName()
                                    );

                                })
                                .subscribeOn(Schedulers.boundedElastic())
                )

                .onErrorMap(ex ->
                        ex instanceof XmlConverterException
                                ? ex
                                : new XmlConverterException(
                                "Error convirtiendo XML a objeto: "
                                        + clazz.getSimpleName(),
                                ex
                        )
                );
    }

    private JAXBContext getContext(Class<?> clazz) {

        return contextCache.computeIfAbsent(
                clazz,
                this::createContext
        );
    }

    private JAXBContext createContext(Class<?> clazz) {

        return Mono.fromCallable(() ->
                        JAXBContext.newInstance(clazz)
                )
                .onErrorMap(ex ->
                        new XmlConverterException(
                                "Error creando JAXBContext para: "
                                        + clazz.getName(),
                                ex
                        )
                )
                .block();
    }
}