package com.pichincha.sp.domain.dto;

public record WsProductos0024RequestBodyInDto(
    WsProductos0024RequestOrdenanteDto ordenante
) {
}