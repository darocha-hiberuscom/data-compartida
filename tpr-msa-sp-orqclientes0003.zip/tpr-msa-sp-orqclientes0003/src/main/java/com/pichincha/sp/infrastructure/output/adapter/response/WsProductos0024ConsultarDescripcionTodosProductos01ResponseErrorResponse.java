package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsProductos0024ConsultarDescripcionTodosProductos01ResponseErrorResponse(
    String codigo,
    String mensaje,
    String tipo,
    String recurso,
    String componente,
    String backend
) {
}