package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsProductos0024ConsultarDescripcionTodosProductos01ResponseProductoResponse(
    String cif,
    String numero,
    String principal,
    String tipo,
    String idProducto,
    String descripcion,
    String subtipo
) {
}