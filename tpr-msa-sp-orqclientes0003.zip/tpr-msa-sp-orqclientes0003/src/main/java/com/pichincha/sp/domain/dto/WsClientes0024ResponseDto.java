package com.pichincha.sp.domain.dto;

public record WsClientes0024ResponseDto(
    HeaderOutDto headerOut,
    WsClientes0024ResponseBodyOutDto bodyOut,
    ErrorDto error
) {
}