package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsProductos0023RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0023ResponseDto;
import reactor.core.publisher.Mono;

public interface WsProductos0023PortOutput {
    Mono<WsProductos0023ResponseDto> execute(WsProductos0023RequestDto request);
}
