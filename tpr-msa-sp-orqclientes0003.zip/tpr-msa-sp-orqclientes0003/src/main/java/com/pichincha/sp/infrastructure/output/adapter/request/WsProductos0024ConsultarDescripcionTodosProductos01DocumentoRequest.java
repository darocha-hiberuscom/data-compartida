package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsProductos0024ConsultarDescripcionTodosProductos01DocumentoRequest(
    String fechaContable,
    String numeroDocumento,
    String journals
) {
}