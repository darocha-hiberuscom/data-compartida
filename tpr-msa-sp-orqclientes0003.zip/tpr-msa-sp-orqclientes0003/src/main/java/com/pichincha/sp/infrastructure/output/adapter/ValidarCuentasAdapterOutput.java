package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ValidarCuentasPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0118RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0118ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0118AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ValidarCuentasAdapterOutput implements ValidarCuentasPortOutput {

    @Qualifier("wsProductos0118WebClient")
    private final WebClient wsProductos0118WebClient;
    private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsProductos0118ResponseDto> execute(WsProductos0118RequestDto request) {
        return wsProductos0118WebClient.post()
                .uri("/")
            .bodyValue(outputAdapterMapper.toWsProductos0118Request(request))
                .retrieve()
                .toBodilessEntity()
            .map(ignored -> outputAdapterMapper.toWsProductos0118Response(new WsProductos0118AdapterResponse(
                new WsProductos0118ResponseDto(
                    new WsProductos0118ResponseDto.BodyOutDto(new WsProductos0118ResponseDto.ClienteTarjetasDto(java.util.List.of())),
                    new OrquestadorResponseDto.GenericErrorDto("0003", "Cliente con cuentas", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ValidarCuentasAdapterOutput"));
    }
}
