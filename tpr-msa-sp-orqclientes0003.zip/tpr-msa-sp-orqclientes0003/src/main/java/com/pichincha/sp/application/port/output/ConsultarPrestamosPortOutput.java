package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsClientes0002RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0002ResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultarPrestamosPortOutput {
    Mono<WsClientes0002ResponseDto> execute(WsClientes0002RequestDto request);
}
