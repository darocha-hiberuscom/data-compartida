package com.pichincha.sp.application.service;

import com.pichincha.sp.application.port.input.ConsultarProductosActivos01PortInput;
import com.pichincha.sp.application.service.strategy.OrquestacionStrategyResolver;
import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class ConsultarProductosActivos01Service implements ConsultarProductosActivos01PortInput {

    private final OrquestacionStrategyResolver strategyResolver;

    public ConsultarProductosActivos01Service(OrquestacionStrategyResolver strategyResolver) {
        this.strategyResolver = strategyResolver;
    }

    @Override
    public Mono<OrquestadorResponseDto> execute(OrquestadorRequestDto request) {
        String estado = request == null || request.bodyIn() == null || request.bodyIn().flujo() == null
                ? null
                : request.bodyIn().flujo().estado();
        return strategyResolver.resolve(estado).execute(request);
    }
}
