package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyWsProductos0024Response {

    @XmlElement(name = "ConsultarDescripcionTodosProductos01Response", namespace = "http://bpichincha.com/servicios")
    private ConsultarDescripcionTodosProductos01Response consultarDescripcionTodosProductos01Response;
}
