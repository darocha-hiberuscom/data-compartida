package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;

public record WsClientes0024AdapterRequest(WsClientes0024RequestDto payload) {
}