package com.pichincha.sp.domain.dto;

import java.util.List;

public record WsProductos0118ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            ClienteTarjetasDto clienteTarjetas) {
    }

    public record ClienteTarjetasDto(
            List<ClienteTarjetaDto> clienteTarjeta) {
    }

    public record ClienteTarjetaDto(
            String datosTarjeta,
            String estado,
            String identificacion) {
    }
}
