package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.domain.dto.DocumentoDto;
import com.pichincha.sp.domain.dto.ErrorDto;
import com.pichincha.sp.domain.dto.HeaderOutDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseBodyOutDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.response.BodyOutWsClientes0024;
import com.pichincha.sp.infrastructure.output.adapter.response.ConsultarIdentificacion01Response;
import com.pichincha.sp.infrastructure.output.adapter.response.DocumentoOut;
import com.pichincha.sp.infrastructure.output.adapter.response.ErrorOut;
import com.pichincha.sp.infrastructure.output.adapter.response.HeaderOut;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface WsClientes0024SoapMapper {

    @Mapping(target = "headerOut", source = "headerOut")
    @Mapping(target = "bodyOut", source = "bodyOut")
    @Mapping(target = "error", source = "error")
    WsClientes0024ResponseDto toDomainResponse(ConsultarIdentificacion01Response operation);

    @Mapping(target = "documento", source = "documento")
    HeaderOutDto toHeaderOutDto(HeaderOut headerOut);

    DocumentoDto toDocumentoDto(DocumentoOut documentoOut);

    @Mapping(target = "cIF", source = "cif")
    @Mapping(target = "identificacion", source = "identificacion")
    @Mapping(target = "tipoIdentificacion", source = "tipoIdentificacion")
    @Mapping(target = "nombre", source = "nombre")
    @Mapping(target = "direccion", source = "direccion")
    @Mapping(target = "tipoCliente", source = "tipoCliente")
    @Mapping(target = "estado", source = "estado")
    WsClientes0024ResponseBodyOutDto toBodyOutDto(BodyOutWsClientes0024 bodyOut);

    ErrorDto toErrorDto(ErrorOut errorOut);
}
