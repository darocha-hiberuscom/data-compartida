package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.request.SoapEnvelopeRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface SoapToDomainMapper {

    @Mapping(target = "headerIn", ignore = true)
    @Mapping(target = "bodyIn", ignore = true)
    OrquestadorRequestDto toDomain(SoapEnvelopeRequest request);
}