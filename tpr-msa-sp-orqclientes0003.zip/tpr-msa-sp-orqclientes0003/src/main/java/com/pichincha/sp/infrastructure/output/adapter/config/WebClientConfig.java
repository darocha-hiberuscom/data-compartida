package com.pichincha.sp.infrastructure.output.adapter.config;

import com.pichincha.sp.infrastructure.output.adapter.properties.webclient.WebClientProperties;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

public abstract class WebClientConfig {

    protected WebClient.Builder getWebClientBuilder(WebClientProperties.HttpClientProperties properties) {
        ConnectionProvider connectionProvider = ConnectionProvider.builder("orq-client")
                .maxConnections(properties.maxConnections())
                .maxIdleTime(getOrDefault(properties.maxIdleTime(), Duration.ofSeconds(30)))
                .pendingAcquireMaxCount(properties.pendingAcquireMaxCount())
                .pendingAcquireTimeout(getOrDefault(properties.pendingAcquireTimeout(), Duration.ofSeconds(30)))
                .build();

        HttpClient httpClient = HttpClient.create(connectionProvider)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, properties.connectionTimeout())
                .doOnConnected(conn -> conn
                        .addHandlerLast(new ReadTimeoutHandler(
                                getOrDefault(properties.readTimeout(), Duration.ofSeconds(30)).toSeconds(),
                                TimeUnit.SECONDS)));

        WebClient.Builder builder = WebClient.builder()
                .baseUrl(properties.uri())
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        List<String> headers = properties.httpHeaders();
        if (headers != null) {
            headers.stream()
                    .map(entry -> entry.split("=", 2))
                    .filter(parts -> parts.length == 2)
                    .forEach(parts -> builder.defaultHeader(parts[0].trim(), parts[1].trim()));
        }
        return builder;
    }

    private static Duration getOrDefault(Duration value, Duration fallback) {
        return value == null ? fallback : value;
    }
}
