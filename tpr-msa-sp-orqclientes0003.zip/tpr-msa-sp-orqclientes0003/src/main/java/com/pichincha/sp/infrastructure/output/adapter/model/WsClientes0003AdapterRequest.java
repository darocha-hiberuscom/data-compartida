package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0003RequestDto;

public record WsClientes0003AdapterRequest(WsClientes0003RequestDto payload) {
}