package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.AysWsclientes0220ResponseDto;

public record AysWsclientes0220AdapterResponse(AysWsclientes0220ResponseDto payload) {
}