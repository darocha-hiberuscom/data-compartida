package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsProductos0123RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0123ResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultarDatosBinPortOutput {
    Mono<WsProductos0123ResponseDto> execute(WsProductos0123RequestDto request);
}
