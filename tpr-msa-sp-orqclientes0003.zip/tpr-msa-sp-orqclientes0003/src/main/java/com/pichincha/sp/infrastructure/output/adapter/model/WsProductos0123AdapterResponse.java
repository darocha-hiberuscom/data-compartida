package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0123ResponseDto;

public record WsProductos0123AdapterResponse(WsProductos0123ResponseDto payload) {
}