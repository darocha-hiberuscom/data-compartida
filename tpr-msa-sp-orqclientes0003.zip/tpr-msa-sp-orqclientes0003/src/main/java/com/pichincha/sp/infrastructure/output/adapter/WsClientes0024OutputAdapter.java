package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.WsClientes0024PortOutput;
import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.builder.WsClientes0024SoapBuilder;
import com.pichincha.sp.infrastructure.output.adapter.builder.WsClientes0024SoapResponseBuilder;
import com.pichincha.sp.infrastructure.output.adapter.excecutor.SoapWebClientExecutor;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapEnvelopeWsClientes0024Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class WsClientes0024OutputAdapter implements WsClientes0024PortOutput {

    private final SoapWebClientExecutor executor;
    private final WsClientes0024SoapBuilder builder;
        private final WsClientes0024SoapResponseBuilder responseBuilder;

    public WsClientes0024OutputAdapter(
            SoapWebClientExecutor executor,
            WsClientes0024SoapBuilder builder,
            WsClientes0024SoapResponseBuilder responseBuilder
    ) {
        this.executor = executor;
        this.builder = builder;
        this.responseBuilder = responseBuilder;
    }

    @Value("${webclient.wsClientes0024.base-url}")
    private String baseUrl;

    @Value("${webclient.wsClientes0024.path}")
    private String path;

    @Override
    public Mono<WsClientes0024ResponseDto> execute(WsClientes0024RequestDto request) {
        return Mono.just(request)
            .flatMap(requestDto ->
                        executor.execute(
                                baseUrl + path,
                    builder.buildSoapRequest(requestDto),
                                SoapEnvelopeWsClientes0024Response.class
                        )
                    .map(responseBuilder::buildResponse)
                )
            ;
    }
}
