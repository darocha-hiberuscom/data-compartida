package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.sp.application.port.input.ConsultarProductosActivos01PortInput;
import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.exception.BusinessException;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.OrquestadorSoapRequestMapper;
import com.pichincha.sp.infrastructure.input.adapter.rest.mapper.OrquestadorSoapResponseMapper;
import com.pichincha.sp.infrastructure.input.adapter.rest.presenter.OrquestadorPresenter;
import com.pichincha.sp.infrastructure.input.adapter.rest.validator.ConsultarProductosActivos01Validator;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/orq-clientes-0003")
public class OrqClientes0003Controller {

    private final ConsultarProductosActivos01PortInput portInput;
    private final OrquestadorSoapRequestMapper requestMapper;
    private final OrquestadorSoapResponseMapper responseMapper;
    private final OrquestadorPresenter presenter;
    private final ConsultarProductosActivos01Validator validator;

    public OrqClientes0003Controller(
            ConsultarProductosActivos01PortInput portInput,
            OrquestadorSoapRequestMapper requestMapper,
            OrquestadorSoapResponseMapper responseMapper,
            OrquestadorPresenter presenter,
            ConsultarProductosActivos01Validator validator) {
        this.portInput = portInput;
        this.requestMapper = requestMapper;
        this.responseMapper = responseMapper;
        this.presenter = presenter;
        this.validator = validator;
    }

    @PostMapping(
            path = "/consultar-productos-activos-01",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<OrquestadorResponseDto>> consultarProductosActivos01(
            @RequestBody OrquestadorRequestDto request) {
        return Mono.justOrEmpty(request)
                .doOnNext(validator::validate)
                .map(requestMapper::toDomain)
                .flatMap(portInput::execute)
                .map(responseMapper::toSoapResponse)
                .map(ResponseEntity::ok)
                .onErrorResume(BusinessException.class, error -> Mono.just(ResponseEntity.ok(presenter.buildFunctionalError(error))))
                .onErrorResume(error -> Mono.just(ResponseEntity.internalServerError().body(presenter.buildGenericFault())));
    }
}
