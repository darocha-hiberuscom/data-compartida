package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.domain.dto.AysWsclientes0220RequestDto;
import com.pichincha.sp.domain.dto.AysWsclientes0220ResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0002RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0002ResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0003RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0003ResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0114RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0114ResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0023RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0023ResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0118RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0118ResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0123RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0123ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.model.AysWsclientes0220AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.AysWsclientes0220AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0002AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0002AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0003AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0003AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0024AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0024AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0114AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0114AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0023AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0023AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0024AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0024AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0118AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0118AdapterResponse;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0123AdapterRequest;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0123AdapterResponse;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OutputAdapterMapper {

    default WsClientes0024AdapterRequest toWsClientes0024Request(WsClientes0024RequestDto source) {
        return new WsClientes0024AdapterRequest(source);
    }

    default WsClientes0024ResponseDto toWsClientes0024Response(WsClientes0024AdapterResponse source) {
        return source.payload();
    }

    default WsProductos0023AdapterRequest toWsProductos0023Request(WsProductos0023RequestDto source) {
        return new WsProductos0023AdapterRequest(source);
    }

    default WsProductos0023ResponseDto toWsProductos0023Response(WsProductos0023AdapterResponse source) {
        return source.payload();
    }

    default WsProductos0024AdapterRequest toWsProductos0024Request(WsProductos0024RequestDto source) {
        return new WsProductos0024AdapterRequest(source);
    }

    default WsProductos0024ResponseDto toWsProductos0024Response(WsProductos0024AdapterResponse source) {
        return source.payload();
    }

    default WsClientes0114AdapterRequest toWsClientes0114Request(WsClientes0114RequestDto source) {
        return new WsClientes0114AdapterRequest(source);
    }

    default WsClientes0114ResponseDto toWsClientes0114Response(WsClientes0114AdapterResponse source) {
        return source.payload();
    }

    default WsClientes0002AdapterRequest toWsClientes0002Request(WsClientes0002RequestDto source) {
        return new WsClientes0002AdapterRequest(source);
    }

    default WsClientes0002ResponseDto toWsClientes0002Response(WsClientes0002AdapterResponse source) {
        return source.payload();
    }

    default WsClientes0003AdapterRequest toWsClientes0003Request(WsClientes0003RequestDto source) {
        return new WsClientes0003AdapterRequest(source);
    }

    default WsClientes0003ResponseDto toWsClientes0003Response(WsClientes0003AdapterResponse source) {
        return source.payload();
    }

    default AysWsclientes0220AdapterRequest toAysWsclientes0220Request(AysWsclientes0220RequestDto source) {
        return new AysWsclientes0220AdapterRequest(source);
    }

    default AysWsclientes0220ResponseDto toAysWsclientes0220Response(AysWsclientes0220AdapterResponse source) {
        return source.payload();
    }

    default WsProductos0123AdapterRequest toWsProductos0123Request(WsProductos0123RequestDto source) {
        return new WsProductos0123AdapterRequest(source);
    }

    default WsProductos0123ResponseDto toWsProductos0123Response(WsProductos0123AdapterResponse source) {
        return source.payload();
    }

    default WsProductos0118AdapterRequest toWsProductos0118Request(WsProductos0118RequestDto source) {
        return new WsProductos0118AdapterRequest(source);
    }

    default WsProductos0118ResponseDto toWsProductos0118Response(WsProductos0118AdapterResponse source) {
        return source.payload();
    }
}