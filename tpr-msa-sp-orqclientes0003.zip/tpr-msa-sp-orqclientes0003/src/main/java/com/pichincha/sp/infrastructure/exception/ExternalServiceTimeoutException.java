package com.pichincha.sp.infrastructure.exception;

public class ExternalServiceTimeoutException extends InfrastructureException {

    public ExternalServiceTimeoutException(String message, String component) {
        super(message, component);
    }
}
