package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class Bancs {

    @XmlElement(name = "teller")
    private String teller;

    @XmlElement(name = "terminal")
    private String terminal;

    @XmlElement(name = "institucion")
    private String institucion;

    @XmlElement(name = "agencia")
    private String agencia;

    @XmlElement(name = "estacion")
    private String estacion;

    @XmlElement(name = "aplicacion")
    private String aplicacion;

    @XmlElement(name = "canal")
    private String canal;
}
