package com.pichincha.sp.domain.dto;

public record WsProductos0024ResponseDto(
    HeaderOutDto headerOut,
    WsProductos0024ResponseBodyOutDto bodyOut,
    ErrorDto error
) {
}