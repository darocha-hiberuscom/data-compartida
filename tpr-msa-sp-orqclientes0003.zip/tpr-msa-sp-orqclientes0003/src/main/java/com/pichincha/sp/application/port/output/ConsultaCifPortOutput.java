package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultaCifPortOutput {
    Mono<WsClientes0024ResponseDto> execute(WsClientes0024RequestDto request);
}
