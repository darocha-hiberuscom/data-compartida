package com.pichincha.sp.infrastructure.exception;

public class ExternalServiceConnectivityException extends InfrastructureException {

    public ExternalServiceConnectivityException(String message, String component) {
        super(message, component);
    }
}
