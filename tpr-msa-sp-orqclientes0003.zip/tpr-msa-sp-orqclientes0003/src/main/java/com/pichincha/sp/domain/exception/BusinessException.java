package com.pichincha.sp.domain.exception;

public class BusinessException extends RuntimeException {

    private final String code;
    private final String resource;
    private final String applicationName;
    private final String backend;

    public BusinessException(
            String code,
            String message,
            String resource,
            String applicationName,
            String backend) {
        super(message);
        this.code = code;
        this.resource = resource;
        this.applicationName = applicationName;
        this.backend = backend;
    }

    public String getCode() {
        return code;
    }

    public String getResource() {
        return resource;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public String getBackend() {
        return backend;
    }
}
