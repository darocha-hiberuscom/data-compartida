package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyWsClientes0024Response {

    @XmlElement(name = "ConsultarIdentificacion01Response", namespace = "http://bpichincha.com/servicios")
    private ConsultarIdentificacion01Response consultarIdentificacion01Response;

    public ConsultarIdentificacion01Response getConsultarIdentificacion01Response() {
        return consultarIdentificacion01Response;
    }
}
