package com.pichincha.sp.domain.dto;

public record HeaderOutDto(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String agencia,
    String tipoTransaccion,
    String usuario,
    String guid,
    String fechaHora,
    String sesion,
    DocumentoDto documento
) {
}