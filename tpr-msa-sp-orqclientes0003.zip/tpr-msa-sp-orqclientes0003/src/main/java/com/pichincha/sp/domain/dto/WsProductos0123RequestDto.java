package com.pichincha.sp.domain.dto;

public record WsProductos0123RequestDto(
        String codigoProductoCredito,
        String bin) {
}
