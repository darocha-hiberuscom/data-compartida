package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrquestadorSoapResponseMapper {
    OrquestadorResponseDto toSoapResponse(OrquestadorResponseDto response);
}
