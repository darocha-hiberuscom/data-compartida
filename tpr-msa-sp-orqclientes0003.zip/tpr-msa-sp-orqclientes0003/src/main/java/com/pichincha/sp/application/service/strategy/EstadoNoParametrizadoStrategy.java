package com.pichincha.sp.application.service.strategy;

import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class EstadoNoParametrizadoStrategy implements OrquestacionStrategy {

    @Override
    public boolean supports(String estado) {
        return true;
    }

    @Override
    public Mono<OrquestadorResponseDto> execute(OrquestadorRequestDto request) {
        return Mono.just(new OrquestadorResponseDto(
                new OrquestadorResponseDto.GenericHeaderOutDto("6", "valor del estado del flujo no parametrizado"),
                null,
                new OrquestadorResponseDto.GenericErrorDto("6", "valor del estado del flujo no parametrizado", "ERROR")));
    }
}
