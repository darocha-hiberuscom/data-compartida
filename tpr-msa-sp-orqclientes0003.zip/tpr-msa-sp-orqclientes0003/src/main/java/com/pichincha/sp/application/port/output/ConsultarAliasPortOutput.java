package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultarAliasPortOutput {
    Mono<WsProductos0024ResponseDto> execute(WsProductos0024RequestDto request);
}
