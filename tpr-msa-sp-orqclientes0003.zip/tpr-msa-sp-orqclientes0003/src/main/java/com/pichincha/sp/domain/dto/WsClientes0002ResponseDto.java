package com.pichincha.sp.domain.dto;

import java.util.List;

public record WsClientes0002ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            ProductosDto productos) {
    }

    public record ProductosDto(
            List<CreditoDto> credito) {
    }

    public record CreditoDto(
            String numeroOperacion,
            String descripcionProducto,
            String moneda,
            String cuotaPagar,
            String fechaPago,
            String tipoCredito) {
    }
}
