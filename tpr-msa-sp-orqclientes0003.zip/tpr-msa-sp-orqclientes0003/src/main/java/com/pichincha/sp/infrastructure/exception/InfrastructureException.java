package com.pichincha.sp.infrastructure.exception;

import org.springframework.http.HttpStatus;

public class InfrastructureException extends GlobalErrorException {

    public InfrastructureException(String message, String component) {
        super(message, component, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
