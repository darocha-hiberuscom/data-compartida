package com.pichincha.sp.infrastructure.input.adapter.rest.builder;

import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.generated.ConsultarIdentificacion01;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface WsClientes0024SoapBuilder {

    @Mapping(source = "bodyIn.identificacion", target = "identification")
    @Mapping(source = "bodyIn.tipoIdentificacion", target = "identificationType")
    @Mapping(source = "bodyIn.filtroCuenta", target = "accountFilter")
    @Mapping(source = "bodyIn.canal.referido", target = "channel.referred")
    @Mapping(source = "bodyIn.canal.acceso", target = "channel.access")
    @Mapping(target = "cif", ignore = true)
    WsClientes0024RequestDto toDomain(ConsultarIdentificacion01 request);
}