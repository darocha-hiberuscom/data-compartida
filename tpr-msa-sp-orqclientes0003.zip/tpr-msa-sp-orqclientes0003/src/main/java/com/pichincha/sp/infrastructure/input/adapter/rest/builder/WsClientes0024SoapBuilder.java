package com.pichincha.sp.infrastructure.input.adapter.rest.builder;

import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.generated.ConsultarProductosActivos01;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface WsClientes0024SoapBuilder {

    @Mapping(target = "headerIn", ignore = true)
    @Mapping(target = "bodyIn", ignore = true)
    WsClientes0024RequestDto toDomain(ConsultarProductosActivos01 request);
}