package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarAliasPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsProductos0024AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarAliasAdapterOutput implements ConsultarAliasPortOutput {

    @Qualifier("wsProductos0024WebClient")
    private final WebClient wsProductos0024WebClient;
    private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsProductos0024ResponseDto> execute(WsProductos0024RequestDto request) {
        return wsProductos0024WebClient.post()
                .uri("/")
            .bodyValue(outputAdapterMapper.toWsProductos0024Request(request))
                .retrieve()
                .toBodilessEntity()
            .map(ignored -> outputAdapterMapper.toWsProductos0024Response(new WsProductos0024AdapterResponse(
                new WsProductos0024ResponseDto(
                    new WsProductos0024ResponseDto.BodyOutDto(new WsProductos0024ResponseDto.ProductosDto(java.util.List.of())),
                    new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultarAliasAdapterOutput"));
    }
}
