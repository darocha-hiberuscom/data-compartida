package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarAliasPortOutput;
import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarAliasAdapterOutput implements ConsultarAliasPortOutput {

    private final WsProductos0024OutputAdapter wsProductos0024OutputAdapter;

    @Override
    public Mono<WsProductos0024ResponseDto> execute(WsProductos0024RequestDto request) {
        return wsProductos0024OutputAdapter.execute(request);
    }
}
