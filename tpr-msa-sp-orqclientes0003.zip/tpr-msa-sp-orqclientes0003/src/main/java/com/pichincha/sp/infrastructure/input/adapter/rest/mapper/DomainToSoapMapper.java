package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.generated.OperacionSoapResponse;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DomainToSoapMapper {

    @Mapping(target = "headerOut", ignore = true)
    @Mapping(target = "bodyOut", ignore = true)
    @Mapping(target = "error.codigo", source = "error.codigo")
    @Mapping(target = "error.mensaje", source = "error.mensaje")
    @Mapping(target = "error.mensajeNegocio", source = "error.mensajeNegocio")
    @Mapping(target = "error.tipo", source = "error.tipo")
    @Mapping(target = "error.recurso", source = "error.recurso")
    @Mapping(target = "error.componente", source = "error.componente")
    @Mapping(target = "error.backend", source = "error.backend")
    OperacionSoapResponse toOperationResponse(OrquestadorResponseDto result);

    @Mapping(target = "body.operacionSoapResponse", source = "operationResponse")
    SoapEnvelopeResponse toEnvelope(OperacionSoapResponse operationResponse);
}