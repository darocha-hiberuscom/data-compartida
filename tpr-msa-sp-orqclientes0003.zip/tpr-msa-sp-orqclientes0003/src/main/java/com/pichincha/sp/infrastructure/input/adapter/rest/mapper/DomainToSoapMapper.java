package com.pichincha.sp.infrastructure.input.adapter.rest.mapper;

import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.generated.ConsultarProductosActivos01Response;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.response.SoapEnvelopeResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DomainToSoapMapper {

    @Mapping(target = "headerOut", ignore = true)
    @Mapping(target = "bodyOut", ignore = true)
    @Mapping(target = "error", ignore = true)
    ConsultarProductosActivos01Response toOperationResponse(OrquestadorResponseDto result);

    @Mapping(target = "body.operacionSoapResponse", source = "operationResponse")
    SoapEnvelopeResponse toEnvelope(ConsultarProductosActivos01Response operationResponse);
}