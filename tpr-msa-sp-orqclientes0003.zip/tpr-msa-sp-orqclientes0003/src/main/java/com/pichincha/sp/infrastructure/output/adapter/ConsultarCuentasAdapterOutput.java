package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarCuentasPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0114RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0114ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0114AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarCuentasAdapterOutput implements ConsultarCuentasPortOutput {

    @Qualifier("wsClientes0114WebClient")
    private final WebClient wsClientes0114WebClient;
    private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsClientes0114ResponseDto> execute(WsClientes0114RequestDto request) {
        return wsClientes0114WebClient.post()
                .uri("/")
                .bodyValue(outputAdapterMapper.toWsClientes0114Request(request))
                .retrieve()
                .toBodilessEntity()
                .map(ignored -> outputAdapterMapper.toWsClientes0114Response(new WsClientes0114AdapterResponse(emptyResponse())))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultarCuentasAdapterOutput"));
    }

    private WsClientes0114ResponseDto emptyResponse() {
        return new WsClientes0114ResponseDto(
                new WsClientes0114ResponseDto.BodyOutDto(
                        new WsClientes0114ResponseDto.CuentasDto(
                                new WsClientes0114ResponseDto.CorrientesDto(java.util.List.of()),
                                new WsClientes0114ResponseDto.AhorrosDto(java.util.List.of()),
                                new WsClientes0114ResponseDto.InversionesDto(java.util.List.of()))),
                new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO"));
    }
}
