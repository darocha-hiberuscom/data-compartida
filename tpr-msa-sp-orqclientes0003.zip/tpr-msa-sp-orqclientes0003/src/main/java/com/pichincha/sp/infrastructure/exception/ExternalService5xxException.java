package com.pichincha.sp.infrastructure.exception;

public class ExternalService5xxException extends InfrastructureException {

    public ExternalService5xxException(String message, String component) {
        super(message, component);
    }
}
