package com.pichincha.sp.domain.dto;

public record WsClientes0003RequestDto(
        String identificacion,
        String tipoIdentificacion) {
}
