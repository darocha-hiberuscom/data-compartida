package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class DocumentoOut {

    @XmlElement(name = "fechaContable")
    private String fechaContable;

    @XmlElement(name = "numeroDocumento")
    private String numeroDocumento;

    public String getFechaContable() {
        return fechaContable;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }
}
