package com.pichincha.sp.infrastructure.output.adapter.excecutor;

import com.pichincha.sp.infrastructure.output.adapter.converter.XmlConverter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class SoapWebClientExecutor {

    private final WebClient webClient;
    private final XmlConverter xmlConverter;

    public <REQ, RES> Mono<RES> execute(
            String url,
            REQ request,
            Class<RES> responseClass
    ) {
        return xmlConverter.toXml(request)
                .flatMap(xmlRequest -> callSoap(url, xmlRequest))
                .flatMap(xmlResponse -> xmlConverter.fromXml(xmlResponse, responseClass));
    }

    private Mono<String> callSoap(String url, String xmlRequest) {
        return webClient.post()
                .uri(url)
                .header(HttpHeaders.CONTENT_TYPE, "text/xml; charset=UTF-8")
                .header("SOAPAction", "")
                .bodyValue(xmlRequest)
                .retrieve()
                .bodyToMono(String.class);
    }
}