package com.pichincha.sp.infrastructure.output.adapter.excecutor;

import com.pichincha.sp.domain.exception.XmlConverterException;
import com.pichincha.sp.infrastructure.output.adapter.converter.XmlConverter;
import com.pichincha.sp.infrastructure.output.adapter.properties.webclient.WebClientProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;

@Component
@RequiredArgsConstructor
public class SoapWebClientExecutor {

    private final WebClient webClient;
    private final XmlConverter xmlConverter;

    public <REQ, RES> Mono<RES> execute(
            String url,
            REQ request,
            Class<RES> responseClass,
            WebClientProperties.HttpClientProperties properties
    ) {
        return xmlConverter.toXml(request)
                .flatMap(xmlRequest -> callSoapWithProperties(url, xmlRequest, properties))
                .flatMap(xmlResponse -> xmlConverter.fromXml(xmlResponse, responseClass));
    }

    private Mono<String> callSoapWithProperties(
            String url,
            String xmlRequest,
            WebClientProperties.HttpClientProperties properties
    ) {
        return Mono.fromCallable(() -> {
                    if (properties == null) {
                        throw new XmlConverterException("WebClientProperties no pueden ser null");
                    }
                    return properties;
                })
                .flatMap(httpProps ->
                        buildRequestWithProperties(url, xmlRequest, httpProps)
                )
                .onErrorMap(ex ->
                        ex instanceof XmlConverterException
                                ? ex
                                : new XmlConverterException(
                                "Error en invocación SOAP: " + ex.getMessage(),
                                ex
                        )
                );
    }

    private Mono<String> buildRequestWithProperties(
            String url,
            String xmlRequest,
            WebClientProperties.HttpClientProperties props
    ) {
        WebClient.RequestBodySpec requestBodySpec = webClient.post()
                .uri(url)
                .header(HttpHeaders.CONTENT_TYPE, "text/xml; charset=UTF-8")
                .header("SOAPAction", "");

        if (props.httpHeaders() != null && !props.httpHeaders().isEmpty()) {
            for (String header : props.httpHeaders()) {
                String[] parts = header.split("=", 2);
                if (parts.length == 2) {
                    requestBodySpec.header(parts[0].trim(), parts[1].trim());
                }
            }
        }

        return requestBodySpec
                .bodyValue(xmlRequest)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(
                        Duration.ofMillis(
                                props.readTimeout() != null
                                        ? props.readTimeout().toMillis()
                                        : 30000L
                        )
                );
    }
}