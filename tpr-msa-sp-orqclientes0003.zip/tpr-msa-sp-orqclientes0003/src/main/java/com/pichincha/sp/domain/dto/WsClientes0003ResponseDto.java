package com.pichincha.sp.domain.dto;

import java.util.List;

public record WsClientes0003ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            TarjetasDto tarjetas) {
    }

    public record TarjetasDto(
            List<TarjetaDto> tarjeta) {
    }

    public record TarjetaDto(
            String numeroTarjeta,
            String tipoTarjeta,
            String emisor,
            String minimoPagar,
            String totalPagarFecha,
            String fechaProximoPago,
            String saldoTarjeta) {
    }
}
