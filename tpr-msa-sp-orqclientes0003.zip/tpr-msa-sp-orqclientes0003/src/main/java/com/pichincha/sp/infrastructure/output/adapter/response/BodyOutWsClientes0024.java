package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class BodyOutWsClientes0024 {

    @XmlElement(name = "cif")
    private String cif;

    @XmlElement(name = "identificacion")
    private String identificacion;

    @XmlElement(name = "tipoIdentificacion")
    private String tipoIdentificacion;

    @XmlElement(name = "nombre")
    private String nombre;

    @XmlElement(name = "direccion")
    private String direccion;

    @XmlElement(name = "tipoCliente")
    private String tipoCliente;

    @XmlElement(name = "estado")
    private String estado;

    public String getCif() {
        return cif;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public String getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public String getEstado() {
        return estado;
    }
}
