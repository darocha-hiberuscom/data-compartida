package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsClientes0114RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0114ResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultarCuentasAvancePortOutput {
    Mono<WsClientes0114ResponseDto> execute(WsClientes0114RequestDto request);
}
