package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class ErrorOut {

    @XmlElement(name = "codigo")
    private String codigo;

    @XmlElement(name = "mensaje")
    private String mensaje;

    @XmlElement(name = "mensajeNegocio")
    private String mensajeNegocio;

    @XmlElement(name = "tipo")
    private String tipo;

    @XmlElement(name = "recurso")
    private String recurso;

    @XmlElement(name = "componente")
    private String componente;

    @XmlElement(name = "backend")
    private String backend;

    public String getCodigo() {
        return codigo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public String getMensajeNegocio() {
        return mensajeNegocio;
    }

    public String getTipo() {
        return tipo;
    }

    public String getRecurso() {
        return recurso;
    }

    public String getComponente() {
        return componente;
    }

    public String getBackend() {
        return backend;
    }
}
