package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.AysWsclientes0220RequestDto;
import com.pichincha.sp.domain.dto.AysWsclientes0220ResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultarTarjetasOpsPortOutput {
    Mono<AysWsclientes0220ResponseDto> execute(AysWsclientes0220RequestDto request);
}
