package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsClientes0024ConsultarIdentificacion01BodyInRequest(
    String identificacion,
    String tipoIdentificacion
) {
}