package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsClientes0024ConsultarIdentificacion01ResponseBodyOutResponse(
    String cIF,
    String identificacion,
    String tipoIdentificacion,
    String nombre,
    String direccion,
    String tipoCliente,
    String estado
) {
}