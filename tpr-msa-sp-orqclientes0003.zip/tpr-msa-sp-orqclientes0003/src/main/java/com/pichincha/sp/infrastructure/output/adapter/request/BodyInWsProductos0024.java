package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class BodyInWsProductos0024 {

    @XmlElement(name = "ordenante")
    private OrdenanteWsProductos0024 ordenante;
}
