package com.pichincha.sp.domain.dto;

public record OrquestadorHeaderInDto(
        String canal,
        String medio,
        String aplicacion,
        String guid) {
}