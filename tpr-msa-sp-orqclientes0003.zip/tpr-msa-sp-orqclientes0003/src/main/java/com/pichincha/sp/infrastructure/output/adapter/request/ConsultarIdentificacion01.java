package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class ConsultarIdentificacion01 {

    @XmlElement(name = "headerIn")
    private HeaderIn headerIn;

    @XmlElement(name = "bodyIn")
    private BodyInWsClientes0024 bodyIn;

    public void setHeaderIn(HeaderIn headerIn) {
        this.headerIn = headerIn;
    }

    public void setBodyIn(BodyInWsClientes0024 bodyIn) {
        this.bodyIn = bodyIn;
    }
}
