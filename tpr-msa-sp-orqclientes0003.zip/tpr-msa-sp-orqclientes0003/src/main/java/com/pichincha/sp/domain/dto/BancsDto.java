package com.pichincha.sp.domain.dto;

public record BancsDto(
    String teller,
    String terminal,
    String institucion,
    String agencia,
    String estacion,
    String canal
) {
}