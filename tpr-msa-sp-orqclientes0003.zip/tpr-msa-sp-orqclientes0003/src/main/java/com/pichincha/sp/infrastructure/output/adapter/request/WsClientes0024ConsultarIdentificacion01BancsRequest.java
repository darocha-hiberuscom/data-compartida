package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsClientes0024ConsultarIdentificacion01BancsRequest(
    String teller,
    String terminal,
    String institucion,
    String agencia,
    String estacion,
    String canal
) {
}