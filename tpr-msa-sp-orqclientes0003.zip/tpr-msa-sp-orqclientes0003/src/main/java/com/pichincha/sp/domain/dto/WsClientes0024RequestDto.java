package com.pichincha.sp.domain.dto;

public record WsClientes0024RequestDto(
    HeaderInDto headerIn,
    WsClientes0024RequestBodyInDto bodyIn
) {
}