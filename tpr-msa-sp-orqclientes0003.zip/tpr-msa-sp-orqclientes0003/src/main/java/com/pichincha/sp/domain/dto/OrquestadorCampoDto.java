package com.pichincha.sp.domain.dto;

public record OrquestadorCampoDto(
        String nombre,
        String valor) {
}