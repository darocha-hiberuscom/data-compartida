package com.pichincha.sp.infrastructure.output.adapter.builder;

import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;
import com.pichincha.sp.infrastructure.output.adapter.request.BodyInWsProductos0024;
import com.pichincha.sp.infrastructure.output.adapter.request.ConsultarDescripcionTodosProductos01;
import com.pichincha.sp.infrastructure.output.adapter.request.OrdenanteWsProductos0024;
import com.pichincha.sp.infrastructure.output.adapter.request.SoapBodyWsProductos0024Request;
import com.pichincha.sp.infrastructure.output.adapter.request.SoapEnvelopeWsProductos0024Request;
import org.springframework.stereotype.Component;

@Component
public class WsProductos0024SoapBuilder {

    public SoapEnvelopeWsProductos0024Request buildSoapRequest(WsProductos0024RequestDto requestDto) {
        SoapEnvelopeWsProductos0024Request envelope = new SoapEnvelopeWsProductos0024Request();
        SoapBodyWsProductos0024Request soapBody = new SoapBodyWsProductos0024Request();
        ConsultarDescripcionTodosProductos01 operation = new ConsultarDescripcionTodosProductos01();

        BodyInWsProductos0024 bodyIn = new BodyInWsProductos0024();
        OrdenanteWsProductos0024 ordenante = new OrdenanteWsProductos0024();

        if (requestDto != null && requestDto.bodyIn() != null && requestDto.bodyIn().ordenante() != null) {
            ordenante.setCif(requestDto.bodyIn().ordenante().cif());
        }

        bodyIn.setOrdenante(ordenante);
        operation.setBodyIn(bodyIn);
        soapBody.setConsultarDescripcionTodosProductos01(operation);
        envelope.setBody(soapBody);

        return envelope;
    }
}
