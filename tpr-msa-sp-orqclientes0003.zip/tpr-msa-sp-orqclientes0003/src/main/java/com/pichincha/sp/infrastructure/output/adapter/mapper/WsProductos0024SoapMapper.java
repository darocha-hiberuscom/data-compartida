package com.pichincha.sp.infrastructure.output.adapter.mapper;

import com.pichincha.sp.domain.dto.ErrorDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseBodyOutDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseProductoDto;
import com.pichincha.sp.domain.dto.WsProductos0024ResponseProductosDto;
import com.pichincha.sp.infrastructure.output.adapter.response.BodyOutWsProductos0024;
import com.pichincha.sp.infrastructure.output.adapter.response.ConsultarDescripcionTodosProductos01Response;
import com.pichincha.sp.infrastructure.output.adapter.response.ErrorOut;
import com.pichincha.sp.infrastructure.output.adapter.response.ProductoWsProductos0024;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapEnvelopeWsProductos0024Response;
import org.springframework.stereotype.Component;

@Component
public class WsProductos0024SoapMapper {

    public WsProductos0024ResponseDto toDomainResponse(SoapEnvelopeWsProductos0024Response envelope) {
        if (envelope == null || envelope.getBody() == null
                || envelope.getBody().getConsultarDescripcionTodosProductos01Response() == null) {
            return new WsProductos0024ResponseDto(null, null, null);
        }
        return toResponseFromOperation(envelope.getBody().getConsultarDescripcionTodosProductos01Response());
    }

    public WsProductos0024ResponseDto toResponseFromOperation(ConsultarDescripcionTodosProductos01Response response) {
        if (response == null) {
            return new WsProductos0024ResponseDto(null, null, null);
        }
        return new WsProductos0024ResponseDto(
                response.getHeaderOut() == null ? null : new com.pichincha.sp.domain.dto.HeaderOutDto(
                        response.getHeaderOut().getDispositivo(),
                        response.getHeaderOut().getEmpresa(),
                        response.getHeaderOut().getCanal(),
                        response.getHeaderOut().getMedio(),
                        response.getHeaderOut().getAplicacion(),
                        response.getHeaderOut().getAgencia(),
                        response.getHeaderOut().getTipoTransaccion(),
                        response.getHeaderOut().getUsuario(),
                        response.getHeaderOut().getGuid(),
                        response.getHeaderOut().getFechaHora(),
                        response.getHeaderOut().getSesion(),
                        response.getHeaderOut().getDocumento() == null ? null : new com.pichincha.sp.domain.dto.DocumentoDto(
                                response.getHeaderOut().getDocumento().getFechaContable(),
                                response.getHeaderOut().getDocumento().getNumeroDocumento()
                        )
                ),
                toBodyOut(response.getBodyOut()),
                toErrorDto(response.getError())
        );
    }

    public WsProductos0024ResponseBodyOutDto toBodyOut(BodyOutWsProductos0024 bodyOut) {
        if (bodyOut == null || bodyOut.getProductos() == null) {
            return null;
        }
        WsProductos0024ResponseProductoDto producto = bodyOut.getProductos().getProducto() == null
                || bodyOut.getProductos().getProducto().isEmpty()
                ? null
                : toProductoDto(bodyOut.getProductos().getProducto().get(0));
        return new WsProductos0024ResponseBodyOutDto(new WsProductos0024ResponseProductosDto(producto));
    }

    public WsProductos0024ResponseProductoDto toProductoDto(ProductoWsProductos0024 producto) {
        if (producto == null) {
            return null;
        }
        return new WsProductos0024ResponseProductoDto(
                producto.getCif(),
                producto.getNumero(),
                producto.getPrincipal(),
                producto.getTipo(),
                producto.getIdProducto(),
                producto.getDescripcion(),
                producto.getSubtipo()
        );
    }

    public ErrorDto toErrorDto(ErrorOut error) {
        if (error == null) {
            return null;
        }
        return new ErrorDto(
                error.getCodigo(),
                error.getMensaje(),
                error.getMensajeNegocio(),
                error.getTipo(),
                error.getRecurso(),
                error.getComponente(),
                error.getBackend()
        );
    }
}
