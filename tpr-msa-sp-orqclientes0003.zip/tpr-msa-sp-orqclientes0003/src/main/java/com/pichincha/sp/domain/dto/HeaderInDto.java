package com.pichincha.sp.domain.dto;

public record HeaderInDto(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String agencia,
    String tipoTransaccion,
    String geolocalizacion,
    String usuario,
    String unicidad,
    String guid,
    String fechaHora,
    String filler,
    String idioma,
    String sesion,
    String ip,
    String idCliente,
    String tipoIdCliente,
    BancsDto bancs
) {
}