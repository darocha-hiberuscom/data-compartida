package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsClientes0003ResponseDto;

public record WsClientes0003AdapterResponse(WsClientes0003ResponseDto payload) {
}