package com.pichincha.sp.infrastructure.output.adapter.properties.webclient;

import java.time.Duration;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "webclient")
public record WebClientProperties(
        HttpClientProperties transactionJournal,
        HttpClientProperties depositDetail,
        HttpClientProperties depositImages,
        HttpClientProperties customerPayments,
        HttpClientProperties accountTransaction,
        HttpClientProperties wsClientes0024,
        HttpClientProperties wsProductos0024,
        HttpClientProperties wsProductos0023,
        HttpClientProperties wsClientes0114,
        HttpClientProperties wsClientes0002,
        HttpClientProperties aysWsclientes0220,
        HttpClientProperties wsClientes0003,
        HttpClientProperties wsProductos0123,
        HttpClientProperties wsProductos0118) {

    public record HttpClientProperties(
            int connectionTimeout,
            Duration readTimeout,
            int maxConnections,
            Duration maxIdleTime,
            int pendingAcquireMaxCount,
            List<String> httpHeaders,
            Duration pendingAcquireTimeout,
            String uri) {
    }
}
