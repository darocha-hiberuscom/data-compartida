package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0024RequestDto;

public record WsProductos0024AdapterRequest(WsProductos0024RequestDto payload) {
}