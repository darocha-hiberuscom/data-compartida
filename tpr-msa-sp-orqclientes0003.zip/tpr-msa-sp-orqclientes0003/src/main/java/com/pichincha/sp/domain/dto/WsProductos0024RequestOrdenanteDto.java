package com.pichincha.sp.domain.dto;

public record WsProductos0024RequestOrdenanteDto(
    String cif
) {
}