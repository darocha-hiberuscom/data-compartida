package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0118ResponseDto;

public record WsProductos0118AdapterResponse(WsProductos0118ResponseDto payload) {
}