package com.pichincha.sp.domain.dto;

public record WsProductos0123ResponseDto(
        BodyOutDto bodyOut,
        OrquestadorResponseDto.GenericErrorDto error) {

    public record BodyOutDto(
            ProductoCreditoDto productoCredito) {
    }

    public record ProductoCreditoDto(
            String montoMinimo,
            String montoMaximo,
            String bancoEmisor,
            String descripcion) {
    }
}
