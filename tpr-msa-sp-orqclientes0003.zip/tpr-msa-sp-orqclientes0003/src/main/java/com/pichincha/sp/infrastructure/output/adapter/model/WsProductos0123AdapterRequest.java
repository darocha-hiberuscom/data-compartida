package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.WsProductos0123RequestDto;

public record WsProductos0123AdapterRequest(WsProductos0123RequestDto payload) {
}