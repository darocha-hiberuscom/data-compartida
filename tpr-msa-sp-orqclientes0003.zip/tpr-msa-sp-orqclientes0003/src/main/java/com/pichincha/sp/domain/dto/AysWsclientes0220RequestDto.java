package com.pichincha.sp.domain.dto;

public record AysWsclientes0220RequestDto(
        HeaderInDto headerIn,
        BodyInDto bodyIn) {

    public record HeaderInDto(
            String canal,
            String medio,
            String aplicacion,
            String guid) {
    }

    public record BodyInDto(
            OrdenanteDto ordenante,
            AtributosDto atributos) {
    }

    public record OrdenanteDto(
            String codigoPortal,
            String identificacion) {
    }

    public record AtributosDto(
            String aplicacionId,
            String canalId,
            String nivelTrace,
            String nombreServicio,
            String cantRegistros,
            String numTotalPag,
            String numPagActual) {
    }
}
