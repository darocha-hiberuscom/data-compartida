package com.pichincha.sp.domain.dto;

public record OrquestadorResponseDto(
        OrquestadorHeaderOutDto headerOut,
        OrquestadorBodyOutDto bodyOut,
        OrquestadorErrorDto error) {
}