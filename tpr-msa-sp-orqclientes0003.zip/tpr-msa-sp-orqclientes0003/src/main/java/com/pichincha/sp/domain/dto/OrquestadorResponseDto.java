package com.pichincha.sp.domain.dto;

public record OrquestadorResponseDto(
        OrquestadorHeaderOutDto headerOut,
        OrquestadorBodyOutDto bodyOut,
        OrquestadorErrorDto error) {

    public record GenericHeaderOutDto(
            String codigo,
            String mensaje) {
    }

    public record GenericErrorDto(
            String codigo,
            String mensaje,
            String tipo) {
    }

    public record InformacionCorrienteDto() {
    }

    public record InformacionAhorroDto() {
    }

    public record InformacionInversionDto() {
    }
}