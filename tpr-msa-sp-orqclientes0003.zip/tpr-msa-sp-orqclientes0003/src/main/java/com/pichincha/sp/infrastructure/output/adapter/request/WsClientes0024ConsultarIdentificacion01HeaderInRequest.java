package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsClientes0024ConsultarIdentificacion01HeaderInRequest(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String agencia,
    String tipoTransaccion,
    String geolocalizacion,
    String usuario,
    String unicidad,
    String guid,
    String fechaHora,
    String filler,
    String idioma,
    String sesion,
    String ip,
    String idCliente,
    String tipoIdCliente,
    WsClientes0024ConsultarIdentificacion01BancsRequest bancs
) {
}