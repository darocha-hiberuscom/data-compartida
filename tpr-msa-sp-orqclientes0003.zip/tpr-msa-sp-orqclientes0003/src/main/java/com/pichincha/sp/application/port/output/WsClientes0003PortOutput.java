package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsClientes0003RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0003ResponseDto;
import reactor.core.publisher.Mono;

public interface WsClientes0003PortOutput {
    Mono<WsClientes0003ResponseDto> execute(WsClientes0003RequestDto request);
}
