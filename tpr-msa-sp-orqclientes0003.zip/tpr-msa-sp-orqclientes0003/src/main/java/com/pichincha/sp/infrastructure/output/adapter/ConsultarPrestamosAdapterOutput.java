package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarPrestamosPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0002RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0002ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0002AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarPrestamosAdapterOutput implements ConsultarPrestamosPortOutput {

    @Qualifier("wsClientes0002WebClient")
    private final WebClient wsClientes0002WebClient;
    private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsClientes0002ResponseDto> execute(WsClientes0002RequestDto request) {
        return wsClientes0002WebClient.post()
                .uri("/")
            .bodyValue(outputAdapterMapper.toWsClientes0002Request(request))
                .retrieve()
                .toBodilessEntity()
            .map(ignored -> outputAdapterMapper.toWsClientes0002Response(new WsClientes0002AdapterResponse(
                new WsClientes0002ResponseDto(
                    new WsClientes0002ResponseDto.BodyOutDto(new WsClientes0002ResponseDto.ProductosDto(java.util.List.of())),
                    new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultarPrestamosAdapterOutput"));
    }
}
