package com.pichincha.sp.infrastructure.output.adapter.builder;

import com.pichincha.sp.domain.dto.BancsDto;
import com.pichincha.sp.domain.dto.DocumentoDto;
import com.pichincha.sp.domain.dto.ErrorDto;
import com.pichincha.sp.domain.dto.HeaderOutDto;
import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseBodyOutDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.mapper.WsClientes0024SoapMapper;
import com.pichincha.sp.infrastructure.output.adapter.response.BodyOutWsClientes0024;
import com.pichincha.sp.infrastructure.output.adapter.response.ConsultarIdentificacion01Response;
import com.pichincha.sp.infrastructure.output.adapter.response.DocumentoOut;
import com.pichincha.sp.infrastructure.output.adapter.response.ErrorOut;
import com.pichincha.sp.infrastructure.output.adapter.response.HeaderOut;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapBodyWsClientes0024Response;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapEnvelopeWsClientes0024Response;
import org.springframework.stereotype.Component;

@Component
public class WsClientes0024SoapResponseBuilder {

    private final WsClientes0024SoapMapper mapper;

    public WsClientes0024SoapResponseBuilder(WsClientes0024SoapMapper mapper) {
        this.mapper = mapper;
    }

    public WsClientes0024ResponseDto toDomainResponse(SoapEnvelopeWsClientes0024Response envelope) {
        return buildResponse(null, envelope);
    }

    public WsClientes0024ResponseDto buildResponse(WsClientes0024RequestDto requestDto, SoapEnvelopeWsClientes0024Response envelope) {
        ConsultarIdentificacion01Response operation = extractOperation(envelope);
        if (operation == null) {
            return emptyResponse(requestDto);
        }

        return new WsClientes0024ResponseDto(
                buildHeader(requestDto, operation.getHeaderOut()),
                buildBody(requestDto, operation.getBodyOut()),
                buildError(requestDto, operation.getError())
        );
    }

    public HeaderOutDto buildHeader(WsClientes0024RequestDto requestDto, HeaderOut headerOut) {
        if (headerOut == null) {
            return null;
        }

        buildBancs(requestDto);
        DocumentoDto documento = buildDocumento(headerOut.getDocumento());
        HeaderOutDto mapped = mapper.toHeaderOutDto(headerOut);
        return new HeaderOutDto(
                mapped.dispositivo(),
                mapped.empresa(),
                mapped.canal(),
                mapped.medio(),
                mapped.aplicacion(),
                mapped.agencia(),
                mapped.tipoTransaccion(),
                mapped.usuario(),
                mapped.guid(),
                mapped.fechaHora(),
                mapped.sesion(),
                documento
        );
    }

    public BancsDto buildBancs(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.headerIn() == null || requestDto.headerIn().bancs() == null) {
            return null;
        }

        var bancs = requestDto.headerIn().bancs();
        return new BancsDto(
                bancs.teller(),
                bancs.terminal(),
                bancs.institucion(),
                bancs.agencia(),
                bancs.estacion(),
                bancs.canal()
        );
    }

    public ErrorDto buildError(WsClientes0024RequestDto requestDto, ErrorOut errorOut) {
        if (errorOut == null) {
            return null;
        }

        buildBancs(requestDto);
        return mapper.toErrorDto(errorOut);
    }

    public WsClientes0024ResponseBodyOutDto buildBody(WsClientes0024RequestDto requestDto, BodyOutWsClientes0024 bodyOut) {
        if (bodyOut == null) {
            return null;
        }

        buildBancs(requestDto);
        return mapper.toBodyOutDto(bodyOut);
    }

    public DocumentoDto buildDocumento(DocumentoOut documentoOut) {
        if (documentoOut == null) {
            return null;
        }

        return mapper.toDocumentoDto(documentoOut);
    }

    public ConsultarIdentificacion01Response extractOperation(SoapEnvelopeWsClientes0024Response envelope) {
        if (envelope == null) {
            return null;
        }

        SoapBodyWsClientes0024Response body = envelope.getBody();
        if (body == null) {
            return null;
        }

        return body.getConsultarIdentificacion01Response();
    }

    public WsClientes0024ResponseDto emptyResponse(WsClientes0024RequestDto requestDto) {
        buildBancs(requestDto);
        return new WsClientes0024ResponseDto(null, null, null);
    }
}
