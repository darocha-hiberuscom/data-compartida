package com.pichincha.sp.infrastructure.output.adapter.builder;

import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.mapper.WsClientes0024SoapMapper;
import com.pichincha.sp.infrastructure.output.adapter.response.ConsultarIdentificacion01Response;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapBodyWsClientes0024Response;
import com.pichincha.sp.infrastructure.output.adapter.response.SoapEnvelopeWsClientes0024Response;
import org.springframework.stereotype.Component;

@Component
public class WsClientes0024SoapResponseBuilder {

    private final WsClientes0024SoapMapper mapper;

    public WsClientes0024SoapResponseBuilder(WsClientes0024SoapMapper mapper) {
        this.mapper = mapper;
    }

    public WsClientes0024ResponseDto buildResponse(SoapEnvelopeWsClientes0024Response envelope) {
        ConsultarIdentificacion01Response operation = extractOperation(envelope);
        if (operation == null) {
            return emptyResponse();
        }
        return mapper.toDomainResponse(operation);
    }

    private ConsultarIdentificacion01Response extractOperation(SoapEnvelopeWsClientes0024Response envelope) {
        if (envelope == null) {
            return null;
        }

        SoapBodyWsClientes0024Response body = envelope.getBody();
        if (body == null) {
            return null;
        }

        return body.getConsultarIdentificacion01Response();
    }

    private WsClientes0024ResponseDto emptyResponse() {
        return new WsClientes0024ResponseDto(null, null, null);
    }
}
