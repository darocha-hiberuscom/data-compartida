package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class ConsultarDescripcionTodosProductos01Response {

    @XmlElement(name = "headerOut")
    private HeaderOut headerOut;

    @XmlElement(name = "bodyOut")
    private BodyOutWsProductos0024 bodyOut;

    @XmlElement(name = "error")
    private ErrorOut error;
}
