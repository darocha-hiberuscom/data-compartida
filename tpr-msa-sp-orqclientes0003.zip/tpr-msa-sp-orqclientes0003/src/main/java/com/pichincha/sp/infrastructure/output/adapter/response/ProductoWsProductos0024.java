package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductoWsProductos0024 {

    @XmlElement(name = "cif")
    private String cif;

    @XmlElement(name = "numero")
    private String numero;

    @XmlElement(name = "principal")
    private String principal;

    @XmlElement(name = "tipo")
    private String tipo;

    @XmlElement(name = "idProducto")
    private String idProducto;

    @XmlElement(name = "descripcion")
    private String descripcion;

    @XmlElement(name = "subtipo")
    private String subtipo;
}
