package com.pichincha.sp.infrastructure.output.adapter.request;

public record WsProductos0024ConsultarDescripcionTodosProductos01BodyInRequest(
    WsProductos0024ConsultarDescripcionTodosProductos01OrdenanteRequest ordenante
) {
}