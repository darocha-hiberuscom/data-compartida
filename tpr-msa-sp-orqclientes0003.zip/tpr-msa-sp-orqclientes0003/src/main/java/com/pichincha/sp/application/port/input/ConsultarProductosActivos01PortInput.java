package com.pichincha.sp.application.port.input;

import com.pichincha.sp.domain.dto.OrquestadorRequestDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import reactor.core.publisher.Mono;

public interface ConsultarProductosActivos01PortInput {
    Mono<OrquestadorResponseDto> execute(OrquestadorRequestDto request);
}
