package com.pichincha.sp.application.port.output;

import com.pichincha.sp.domain.dto.WsProductos0118RequestDto;
import com.pichincha.sp.domain.dto.WsProductos0118ResponseDto;
import reactor.core.publisher.Mono;

public interface WsProductos0118PortOutput {
    Mono<WsProductos0118ResponseDto> execute(WsProductos0118RequestDto request);
}
