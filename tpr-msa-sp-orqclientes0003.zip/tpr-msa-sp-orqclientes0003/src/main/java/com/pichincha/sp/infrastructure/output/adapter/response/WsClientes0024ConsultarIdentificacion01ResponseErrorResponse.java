package com.pichincha.sp.infrastructure.output.adapter.response;

public record WsClientes0024ConsultarIdentificacion01ResponseErrorResponse(
    String codigo,
    String mensaje,
    String mensajeNegocio,
    String tipo,
    String recurso,
    String componente,
    String backend
) {
}