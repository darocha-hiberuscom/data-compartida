package com.pichincha.sp.infrastructure.output.adapter.response;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class HeaderOut {

    @XmlElement(name = "dispositivo")
    private String dispositivo;

    @XmlElement(name = "empresa")
    private String empresa;

    @XmlElement(name = "canal")
    private String canal;

    @XmlElement(name = "medio")
    private String medio;

    @XmlElement(name = "aplicacion")
    private String aplicacion;

    @XmlElement(name = "agencia")
    private String agencia;

    @XmlElement(name = "tipoTransaccion")
    private String tipoTransaccion;

    @XmlElement(name = "usuario")
    private String usuario;

    @XmlElement(name = "guid")
    private String guid;

    @XmlElement(name = "fechaHora")
    private String fechaHora;

    @XmlElement(name = "sesion")
    private String sesion;

    @XmlElement(name = "documento")
    private DocumentoOut documento;

    public String getDispositivo() {
        return dispositivo;
    }

    public String getEmpresa() {
        return empresa;
    }

    public String getCanal() {
        return canal;
    }

    public String getMedio() {
        return medio;
    }

    public String getAplicacion() {
        return aplicacion;
    }

    public String getAgencia() {
        return agencia;
    }

    public String getTipoTransaccion() {
        return tipoTransaccion;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getGuid() {
        return guid;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public String getSesion() {
        return sesion;
    }

    public DocumentoOut getDocumento() {
        return documento;
    }
}
