package com.pichincha.sp.infrastructure.output.adapter.model;

import com.pichincha.sp.domain.dto.AysWsclientes0220RequestDto;

public record AysWsclientes0220AdapterRequest(AysWsclientes0220RequestDto payload) {
}