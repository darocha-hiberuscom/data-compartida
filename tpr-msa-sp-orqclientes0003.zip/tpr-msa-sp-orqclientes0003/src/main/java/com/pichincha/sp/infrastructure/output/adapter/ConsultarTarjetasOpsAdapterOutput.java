package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarTarjetasOpsPortOutput;
import com.pichincha.sp.domain.dto.AysWsclientes0220RequestDto;
import com.pichincha.sp.domain.dto.AysWsclientes0220ResponseDto;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.AysWsclientes0220AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarTarjetasOpsAdapterOutput implements ConsultarTarjetasOpsPortOutput {

    @Qualifier("aysWsclientes0220WebClient")
    private final WebClient aysWsclientes0220WebClient;
        private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<AysWsclientes0220ResponseDto> execute(AysWsclientes0220RequestDto request) {
        return aysWsclientes0220WebClient.post()
                .uri("/")
                .bodyValue(outputAdapterMapper.toAysWsclientes0220Request(request))
                .retrieve()
                .toBodilessEntity()
                .map(ignored -> outputAdapterMapper.toAysWsclientes0220Response(new AysWsclientes0220AdapterResponse(
                        new AysWsclientes0220ResponseDto(
                                new AysWsclientes0220ResponseDto.BodyOutDto(
                                        new AysWsclientes0220ResponseDto.DatosTarjetaDto(java.util.List.of())),
                                new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultarTarjetasOpsAdapterOutput"));
    }
}
