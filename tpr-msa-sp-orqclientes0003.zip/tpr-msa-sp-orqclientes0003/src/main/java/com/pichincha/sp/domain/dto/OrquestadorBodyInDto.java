package com.pichincha.sp.domain.dto;

import java.util.List;

public record OrquestadorBodyInDto(
        String identificacion,
        String tipoIdentificacion,
        String cif,
        List<OrquestadorCampoDto> campos) {
}