package com.pichincha.sp.domain.dto;

import java.util.List;

public record OrquestadorBodyInDto(
        String identificacion,
        String tipoIdentificacion,
        String cif,
        List<OrquestadorCampoDto> campos) {

        public String tipoProducto() {
                if (campos == null) {
                        return null;
                }
                return campos.stream()
                                .filter(campo -> campo != null && "tipoProducto".equalsIgnoreCase(campo.nombre()))
                                .map(OrquestadorCampoDto::valor)
                                .findFirst()
                                .orElse(null);
        }

        public FlujoDto flujo() {
                if (campos == null) {
                        return null;
                }
                String estado = campos.stream()
                                .filter(campo -> campo != null && "estado".equalsIgnoreCase(campo.nombre()))
                                .map(OrquestadorCampoDto::valor)
                                .findFirst()
                                .orElse(null);
                return estado == null ? null : new FlujoDto(estado);
        }

        public record FlujoDto(String estado) {
        }
}