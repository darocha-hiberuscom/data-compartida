package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultaCifPortOutput;
import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024ResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultaCifAdapterOutput implements ConsultaCifPortOutput {

    private final WsClientes0024OutputAdapter wsClientes0024OutputAdapter;

    @Override
    public Mono<WsClientes0024ResponseDto> execute(WsClientes0024RequestDto request) {
        return wsClientes0024OutputAdapter.execute(request);
    }
}
