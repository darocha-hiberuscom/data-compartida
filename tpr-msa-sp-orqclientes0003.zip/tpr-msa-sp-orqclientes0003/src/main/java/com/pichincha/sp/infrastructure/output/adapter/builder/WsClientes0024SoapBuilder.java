package com.pichincha.sp.infrastructure.output.adapter.builder;

import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.infrastructure.output.adapter.mapper.WsClientes0024SoapMapper;
import com.pichincha.sp.infrastructure.output.adapter.request.Bancs;
import com.pichincha.sp.infrastructure.output.adapter.request.BodyInWsClientes0024;
import com.pichincha.sp.infrastructure.output.adapter.request.ConsultarIdentificacion01;
import com.pichincha.sp.infrastructure.output.adapter.request.HeaderIn;
import com.pichincha.sp.infrastructure.output.adapter.request.SoapBodyWsClientes0024Request;
import com.pichincha.sp.infrastructure.output.adapter.request.SoapEnvelopeWsClientes0024Request;
import org.springframework.stereotype.Component;

@Component
public class WsClientes0024SoapBuilder {

    private final WsClientes0024SoapMapper mapper;

    public WsClientes0024SoapBuilder(WsClientes0024SoapMapper mapper) {
        this.mapper = mapper;
    }

    public SoapEnvelopeWsClientes0024Request buildSoapRequest(WsClientes0024RequestDto requestDto) {
        SoapEnvelopeWsClientes0024Request envelope = new SoapEnvelopeWsClientes0024Request();
        SoapBodyWsClientes0024Request soapBody = new SoapBodyWsClientes0024Request();
        ConsultarIdentificacion01 operation = new ConsultarIdentificacion01();

        operation.setHeaderIn(buildHeader(requestDto));
        operation.setBodyIn(buildBody(requestDto));
        soapBody.setConsultarIdentificacion01(operation);
        envelope.setBody(soapBody);

        return envelope;
    }

    public HeaderIn buildHeader(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.headerIn() == null) {
            return null;
        }

        return mapper.toHeaderIn(requestDto.headerIn());
    }

    public Bancs buildBancs(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.headerIn() == null || requestDto.headerIn().bancs() == null) {
            return null;
        }

        return mapper.toBancs(requestDto.headerIn());
    }

    public BodyInWsClientes0024 buildBody(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.bodyIn() == null) {
            return null;
        }

        return mapper.toBodyIn(requestDto.bodyIn());
    }
}
