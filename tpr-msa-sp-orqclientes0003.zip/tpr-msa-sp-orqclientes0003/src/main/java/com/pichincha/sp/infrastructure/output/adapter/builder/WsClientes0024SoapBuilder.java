package com.pichincha.sp.infrastructure.output.adapter.builder;

import com.pichincha.sp.domain.dto.BancsDto;
import com.pichincha.sp.domain.dto.HeaderInDto;
import com.pichincha.sp.domain.dto.WsClientes0024RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0024RequestBodyInDto;
import com.pichincha.sp.infrastructure.output.adapter.request.Bancs;
import com.pichincha.sp.infrastructure.output.adapter.request.BodyInWsClientes0024;
import com.pichincha.sp.infrastructure.output.adapter.request.ConsultarIdentificacion01;
import com.pichincha.sp.infrastructure.output.adapter.request.HeaderIn;
import com.pichincha.sp.infrastructure.output.adapter.request.SoapBodyWsClientes0024Request;
import com.pichincha.sp.infrastructure.output.adapter.request.SoapEnvelopeWsClientes0024Request;
import org.springframework.stereotype.Component;

@Component
public class WsClientes0024SoapBuilder {

    public SoapEnvelopeWsClientes0024Request buildSoapRequest(WsClientes0024RequestDto requestDto) {
        SoapEnvelopeWsClientes0024Request envelope = new SoapEnvelopeWsClientes0024Request();
        SoapBodyWsClientes0024Request soapBody = new SoapBodyWsClientes0024Request();
        ConsultarIdentificacion01 operation = new ConsultarIdentificacion01();

        operation.setHeaderIn(buildHeader(requestDto));
        operation.setBodyIn(buildBody(requestDto));
        soapBody.setConsultarIdentificacion01(operation);
        envelope.setBody(soapBody);

        return envelope;
    }

    public HeaderIn buildHeader(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.headerIn() == null) {
            return null;
        }

        HeaderInDto headerInDto = requestDto.headerIn();
        HeaderIn header = new HeaderIn();
        header.setDispositivo(headerInDto.dispositivo());
        header.setEmpresa(headerInDto.empresa());
        header.setCanal(headerInDto.canal());
        header.setMedio(headerInDto.medio());
        header.setAplicacion(headerInDto.aplicacion());
        header.setAgencia(headerInDto.agencia());
        header.setTipoTransaccion(headerInDto.tipoTransaccion());
        header.setGeolocalizacion(headerInDto.geolocalizacion());
        header.setUsuario(headerInDto.usuario());
        header.setUnicidad(headerInDto.unicidad());
        header.setGuid(headerInDto.guid());
        header.setFechaHora(headerInDto.fechaHora());
        header.setFiller(headerInDto.filler());
        header.setIdioma(headerInDto.idioma());
        header.setSesion(headerInDto.sesion());
        header.setIp(headerInDto.ip());
        header.setIdCliente(headerInDto.idCliente());
        header.setTipoIdCliente(headerInDto.tipoIdCliente());
        header.setBancs(buildBancs(requestDto));
        return header;
    }

    public Bancs buildBancs(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.headerIn() == null || requestDto.headerIn().bancs() == null) {
            return null;
        }

        HeaderInDto headerInDto = requestDto.headerIn();
        BancsDto bancsDto = headerInDto.bancs();
        Bancs bancs = new Bancs();
        bancs.setTeller(bancsDto.teller());
        bancs.setTerminal(bancsDto.terminal());
        bancs.setInstitucion(bancsDto.institucion());
        bancs.setAgencia(bancsDto.agencia());
        bancs.setEstacion(bancsDto.estacion());
        bancs.setAplicacion(headerInDto.aplicacion());
        bancs.setCanal(bancsDto.canal());
        return bancs;
    }

    public BodyInWsClientes0024 buildBody(WsClientes0024RequestDto requestDto) {
        if (requestDto == null || requestDto.bodyIn() == null) {
            return null;
        }

        WsClientes0024RequestBodyInDto bodyInDto = requestDto.bodyIn();
        BodyInWsClientes0024 body = new BodyInWsClientes0024();
        body.setIdentificacion(bodyInDto.identificacion());
        body.setTipoIdentificacion(bodyInDto.tipoIdentificacion());
        return body;
    }
}
