package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class HeaderIn {

    @XmlElement(name = "dispositivo")
    private String dispositivo;

    @XmlElement(name = "empresa")
    private String empresa;

    @XmlElement(name = "canal")
    private String canal;

    @XmlElement(name = "medio")
    private String medio;

    @XmlElement(name = "aplicacion")
    private String aplicacion;

    @XmlElement(name = "agencia")
    private String agencia;

    @XmlElement(name = "tipoTransaccion")
    private String tipoTransaccion;

    @XmlElement(name = "geolocalizacion")
    private String geolocalizacion;

    @XmlElement(name = "usuario")
    private String usuario;

    @XmlElement(name = "unicidad")
    private String unicidad;

    @XmlElement(name = "guid")
    private String guid;

    @XmlElement(name = "fechaHora")
    private String fechaHora;

    @XmlElement(name = "filler")
    private String filler;

    @XmlElement(name = "idioma")
    private String idioma;

    @XmlElement(name = "sesion")
    private String sesion;

    @XmlElement(name = "ip")
    private String ip;

    @XmlElement(name = "idCliente")
    private String idCliente;

    @XmlElement(name = "tipoIdCliente")
    private String tipoIdCliente;

    @XmlElement(name = "bancs")
    private Bancs bancs;
}
