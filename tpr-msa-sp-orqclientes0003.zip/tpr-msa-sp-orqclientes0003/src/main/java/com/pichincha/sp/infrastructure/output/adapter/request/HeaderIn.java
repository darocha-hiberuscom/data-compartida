package com.pichincha.sp.infrastructure.output.adapter.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class HeaderIn {

    @XmlElement(name = "dispositivo")
    private String dispositivo;

    @XmlElement(name = "empresa")
    private String empresa;

    @XmlElement(name = "canal")
    private String canal;

    @XmlElement(name = "medio")
    private String medio;

    @XmlElement(name = "aplicacion")
    private String aplicacion;

    @XmlElement(name = "agencia")
    private String agencia;

    @XmlElement(name = "tipoTransaccion")
    private String tipoTransaccion;

    @XmlElement(name = "geolocalizacion")
    private String geolocalizacion;

    @XmlElement(name = "usuario")
    private String usuario;

    @XmlElement(name = "unicidad")
    private String unicidad;

    @XmlElement(name = "guid")
    private String guid;

    @XmlElement(name = "fechaHora")
    private String fechaHora;

    @XmlElement(name = "filler")
    private String filler;

    @XmlElement(name = "idioma")
    private String idioma;

    @XmlElement(name = "sesion")
    private String sesion;

    @XmlElement(name = "ip")
    private String ip;

    @XmlElement(name = "idCliente")
    private String idCliente;

    @XmlElement(name = "tipoIdCliente")
    private String tipoIdCliente;

    @XmlElement(name = "bancs")
    private Bancs bancs;

    public void setDispositivo(String dispositivo) {
        this.dispositivo = dispositivo;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public void setMedio(String medio) {
        this.medio = medio;
    }

    public void setAplicacion(String aplicacion) {
        this.aplicacion = aplicacion;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public void setTipoTransaccion(String tipoTransaccion) {
        this.tipoTransaccion = tipoTransaccion;
    }

    public void setGeolocalizacion(String geolocalizacion) {
        this.geolocalizacion = geolocalizacion;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setUnicidad(String unicidad) {
        this.unicidad = unicidad;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public void setFiller(String filler) {
        this.filler = filler;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public void setSesion(String sesion) {
        this.sesion = sesion;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public void setTipoIdCliente(String tipoIdCliente) {
        this.tipoIdCliente = tipoIdCliente;
    }

    public void setBancs(Bancs bancs) {
        this.bancs = bancs;
    }
}
