package com.pichincha.sp.domain.dto;

import java.util.List;

public record WsProductos0023RequestDto(
        ProductosRequestDto productos) {

    public record ProductosRequestDto(
            List<ProductoRequestDto> producto) {
    }

    public record ProductoRequestDto(
            String tipo) {
    }
}
