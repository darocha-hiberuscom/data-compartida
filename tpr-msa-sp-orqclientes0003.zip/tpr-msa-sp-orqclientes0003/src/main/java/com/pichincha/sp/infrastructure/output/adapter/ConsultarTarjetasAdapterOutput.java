package com.pichincha.sp.infrastructure.output.adapter;

import com.pichincha.sp.application.port.output.ConsultarTarjetasPortOutput;
import com.pichincha.sp.domain.dto.OrquestadorResponseDto;
import com.pichincha.sp.domain.dto.WsClientes0003RequestDto;
import com.pichincha.sp.domain.dto.WsClientes0003ResponseDto;
import com.pichincha.sp.infrastructure.exception.InfrastructureException;
import com.pichincha.sp.infrastructure.output.adapter.mapper.OutputAdapterMapper;
import com.pichincha.sp.infrastructure.output.adapter.model.WsClientes0003AdapterResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class ConsultarTarjetasAdapterOutput implements ConsultarTarjetasPortOutput {

    @Qualifier("wsClientes0003WebClient")
    private final WebClient wsClientes0003WebClient;
    private final OutputAdapterMapper outputAdapterMapper;

    @Override
    public Mono<WsClientes0003ResponseDto> execute(WsClientes0003RequestDto request) {
        return wsClientes0003WebClient.post()
                .uri("/")
            .bodyValue(outputAdapterMapper.toWsClientes0003Request(request))
                .retrieve()
                .toBodilessEntity()
            .map(ignored -> outputAdapterMapper.toWsClientes0003Response(new WsClientes0003AdapterResponse(
                new WsClientes0003ResponseDto(
                    new WsClientes0003ResponseDto.BodyOutDto(new WsClientes0003ResponseDto.TarjetasDto(java.util.List.of())),
                    new OrquestadorResponseDto.GenericErrorDto("0", "OK", "INFO")))))
                .onErrorMap(error -> new InfrastructureException(error.getMessage(), "ConsultarTarjetasAdapterOutput"));
    }
}
